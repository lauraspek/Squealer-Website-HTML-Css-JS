import { useEffect } from 'react';
import React from 'react';
import Typography from '@mui/material/Typography';
import Card from '@mui/material/Card';
import { useState } from 'react';
import CardContent from '@mui/material/CardContent';

const MessaggiTemporizzati = () => {

  var idDateInterval;
  const [currentDate, setCurrentDate] = useState(new Date());
  const email = localStorage.getItem('email');
  
  useEffect(() => {
    idDateInterval = setInterval(() => {
      setCurrentDate(new Date());
    }, 60000);
    return () => clearInterval(idDateInterval);
  }, []);


                  
  const hour = currentDate.getHours();
  var hourAsString = hour.toString(); 
  const lengthHour = hourAsString.length;
  if(lengthHour < 2){
    hourAsString = "0" + hourAsString;
  }


  const minutes = currentDate.getMinutes();
  var minutesAsString = minutes.toString(); 
  const lengthMinutes = minutesAsString.length;
  if(lengthMinutes < 2){
    minutesAsString = "0" + minutesAsString;
  }


  const day = currentDate.toLocaleDateString();
  
  return (

      <div id='news-feed-page'>

        <Card className='news-container'>

          <CardContent>

            <Typography color="text.primary"  sx={{ fontSize: 18 }} gutterBottom>
              Ciao {email}, sono le {hourAsString}:{minutesAsString} del {day}.
            </Typography>

          </CardContent>

        </Card></div>

  );

};

export default MessaggiTemporizzati;