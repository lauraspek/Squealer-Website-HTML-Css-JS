import IconButton from '@mui/material/IconButton';
import React, { useState } from 'react';
import Map from '../../assets/map.png';
import Friend from '../../assets/friend.png';
import './mypost.scss';
import { useEffect } from 'react';
import { MapContainer, TileLayer } from 'react-leaflet'; 
import { useGeolocated } from "react-geolocated";
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import 'leaflet/dist/leaflet.css'
import SendIcon from '@mui/icons-material/Send';
import Image from '../../assets/img.png';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { CheckCircle } from '@mui/icons-material';


const MyPost = () => {
  const username = localStorage.getItem('email');
  const email = localStorage.getItem('email');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogLocOpen, setLocDialogOpen] = useState(false);
  const [inputText, setInputText] = useState(null);
  const [link, setLink] = useState(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedImage, setSelectedImage] = useState(null);
  const [savedImages, setSavedImages] = useState([]);
  const [selectedLat, setSelectedLat] = useState(null);
  const [selectedLon, setSelectedLon] = useState(null);
  const [selectedRecipient, setSelectedRecipient] = useState();  
  const [selectedMentioned, setSelectedMentioned] = useState();
  const [category, setCategory] = useState(null);
  const [recipients, setRecipients] = useState([]);
  const [potentialMentionetedUser, setUsersMentioned] = useState([]);
  const [potentialMentionetedCan, setChannelsMentioned] = useState([]);
  const [userData, setUserData] = useState(null);
  const [errorMessage,setErrorMessage]=useState(false);
  const [mentionDialogOpen, setMentionDialogOpen] = useState(false);
  const [mentionCanDialogOpen, setMentionCanDialogOpen] = useState(false);
  const [rimanenti,setRimanenti] = useState();
  const [imgCar,setImgCar] = useState(false);

  const [selectedImageName,setSelectedImageName]=useState('');
  const image_weight = 200;




  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentDate(new Date());
    }, 1000); 

    return () => clearInterval(interval);
  }, []);


  useEffect(() => {     //prende tutti i destinatari per la menzione
    const searchRecipients = async () => {
      try {
        const response = await axios.get('http://localhost:3001/get/destinatari'); 
        setRecipients(response.data); 
      } catch (error) {
        console.error('Errore durante il recupero dei potential recipients:', error);
      }
    };

    searchRecipients(); 
  }, []);


  useEffect(() => {     //prendo i canali per la menzione
    const searchRecipients = async () => {
      try {
        const response = await axios.get('http://localhost:3001/get/canalimenzionati');
        setChannelsMentioned(response.data); 
      } catch (error) {
        console.error('Errore durante il recupero dei potential recipients:', error);
      }
    };
    searchRecipients(); 
  }, []);


  useEffect(() => {     //prendo tutti gli utenti per la menzione
    const searchRecipients = async () => {
      try {
        const response = await axios.get('http://localhost:3001/get/utentimenzionati'); 
        setUsersMentioned(response.data); 
      } catch (error) {
        console.error('Errore durante il recupero dei potential recipients:', error);
      }
    };

    searchRecipients();
  }, []);



  useEffect(() => {   //prendo l'utente attuale
    axios
    .get(`http://localhost:3001/api/get/${email}`)
      .then((response) => {
        const userFromAPI = response.data[0];
        setUserData(userFromAPI);
        setRimanenti(response.data[0].CaratteriGiornalieri);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);


  const { coords, isGeolocationAvailable, isGeolocationEnabled } =
  useGeolocated({
      positionOptions: {
          enableHighAccuracy: true,
      },
      userDecisionTimeout: 5000,
  });


  if (!userData) {
    return <div>Caricamento...</div>;
  }



  const handleOpenDialog = () => {
    setDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setDialogOpen(false);
  };

  const handleLocOpenDialog = () => {
    setLocDialogOpen(true);
  };

  const handleLocCloseDialog = () => {
    setLocDialogOpen(false);
  };

  const handleErrorOpenDialog = () => {
    setErrorMessage(true);
  };

  const handleErrorCloseDialog = () => {
    setErrorMessage(false);
  };


  const handleKeyDown = event => {
    if (event.key === 'Backspace') {
      setRimanenti(userData.CaratteriGiornalieri - inputText.length + 1 ); 
    } else {
      setRimanenti(rimanenti - 1);
    }
  };

  const handleInputChange = (event) => {
    const inputValue = event.target.value;

    setInputText(inputValue);

    if (inputValue.charAt(inputValue.length - 1) === "@") {
      console.log(inputValue);
      setMentionDialogOpen(true);
    } else if (inputValue.charAt(inputValue.length - 1) === "$") {
      console.log(inputValue);
      setMentionCanDialogOpen(true);
    }else if (selectedMentioned && inputValue.charAt(inputValue.length - 1) === " ") {
      // Aggiunge l'utente selezionato dall'elenco alla fine del testo
      setInputText(inputValue + selectedMentioned + " ");
      setMentionDialogOpen(false); // Chiude il popup dopo l'inserimento
      setSelectedMentioned(null); // Resetta l'utente selezionato
      setMentionCanDialogOpen(false);
      setSelectedMentioned(null);
    }
  };

  const handleMentionConfirm = () => {
    if (selectedMentioned) {
      setInputText(inputText + selectedMentioned + " "); // Aggiunge l'utente selezionato al testo
      setMentionDialogOpen(false); // Chiude il popup dopo l'inserimento
      setSelectedMentioned(null); // Resetta l'utente selezionato
    }
  };

  const handleMentionCanConfirm = () => {
    if (selectedMentioned) {
      setInputText(inputText + selectedMentioned + " "); // Aggiunge il canale selezionato al testo
      setMentionCanDialogOpen(false); // Chiude il popup dopo l'inserimento
      setSelectedMentioned(null); // Resetta il canale selezionato
    }
  };

  const handleClose  = () =>{
    handleRimozioneCaratteri();
  };

  const handleRimozioneCaratteri = async () => {
    try {
      const response = await axios.post('http://localhost:3001/post/RemoveChar', {
        mail: username,
        newChar: userData.CaratteriGiornalieri - rimanenti
      });

      console.log('Risposta dalla stored procedure:', response.data);
      
      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleSaveClick = () => {

    if (!selectedRecipient || selectedRecipient.startsWith('$') ) {
        if(rimanenti <= 0){
          handleErrorOpenDialog();
        } else {
          axios.post("http://localhost:3001/post/Messaggi",
          {
            testo: inputText,
            link:link,
            latititude:selectedLat,
            longitude:selectedLon,
            immagine:selectedImage,
            destinatario: selectedRecipient,
            mittente:username,
            impressionX:0,
            categoria:category,
            data:currentDate,
            menzione:selectedMentioned,

          })
          .then((response) => {
            setSelectedImage(null);
            setInputText('');
            setSelectedMentioned(null);
            handleClose();
            window.location.reload(); 
          })
          .catch((error) => {
            console.error("Errore durante la richiesta API:", error);
          });
         
          alert("Invio andato abuon fine");
          localStorage.setItem('reloadPage',true);
          window.location.reload();        }
    } else {
      axios
      .post("http://localhost:3001/post/Messaggi",
      {
        testo: inputText,
        latititude:selectedLat,
        longitude:selectedLon,
        immagine:selectedImage,
        destinatario: selectedRecipient,
        mittente:username,
        categoria:category,
        data:currentDate,
        menzione:selectedMentioned,
      })
      .then((response) => {
        console.log(response.data);
       
        setSelectedImage(null);
        setInputText('');
        setSelectedMentioned(null);
        handleClose();
        window.location.reload(); 
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
      alert("Invio andato abuon fine");
      window.location.reload(); 
    }
  };


  const handleImageChange = (event) => {
    const imageFile = event.target.files[0];
    const fileName = imageFile.name;
    setSelectedImageName(fileName);
    setSelectedImage(imageFile);
    setImgCar(true);
  };

  const handleImaClose = () => {
    setImgCar(false);
  };


  const handleSaveImage = async () => {
    if (selectedImage) {
      setRimanenti(rimanenti - image_weight);
      setSavedImages([...savedImages, selectedImage]);
      const formData = new FormData();
      formData.append('image', selectedImage);

      let fileName1 = "";

      try {
        const response = await axios.post('http://localhost:3001/upload', formData);
        console.log(`Image '${fileName1}' uploaded successfully`, response);
        fileName1 = selectedImage.name;
        const filePath = `${selectedImageName}`;
        console.log(filePath);
        setSelectedImage(filePath);
      } catch (error) {
        console.error(`Error saving image '${fileName1}'`, error);
      }
    }
  };

  const handleSelectedRecipient = (recipientId) => {
    setSelectedRecipient(recipientId);
  };

  

  return (
    <div className="share">
      <div className="container">
        <Card style={{padding:"5vh", width: '90vw', borderRadius: '0'}}>
          <div className="top">

            <Avatar aria-label="recipe" sx={{ bgcolor: '#5e071a', width:'12vh',height:'6vh',borderRadius:'0', position:'relative', right:'5vh' }}>   
              {userData.name}
            </Avatar>
            <label style={{ position:'relative', right:'4vh' }}>Caratteri Rimanenti: {rimanenti}</label>
            <input
              type="text"
              value={inputText}
              id="inputType"
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              placeholder={`A cosa stai pensando ${username}?`}
            />
          </div>

          <hr />

          <div className="bottom">
            <div className="left">
              <input
                type="file"
                id="file"
                style={{ display: "none" }}
                accept="image/*"
                onChange={handleImageChange}
              />

{selectedImage && (
  <Dialog
    open={imgCar}
    onClose={handleImaClose}
    maxWidth="md"
    fullWidth
  >
    <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle: 'italic' }}>
      Informativa
    </DialogTitle>
    <DialogContent dividers>
      Clicca conferma per salvare l'immagine nel messaggio
    </DialogContent>
    <DialogActions>
      <Button
        style={{ marginTop: '2vh', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius: '10px', height: '5vh', color: 'white' }}
        onClick={() => {
          setSelectedImage(null);
          handleImaClose();
        }}
        color="primary"
      >
        Annulla
      </Button>
      <Button
        style={{ marginTop: '2vh', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius: '10px', height: '5vh', color: 'white' }}
        onClick={() => {
          handleSaveImage();
          handleImaClose();
        }}
        color="primary"
      >
        Conferma
      </Button>
    </DialogActions>
  </Dialog>
)}

              <div>
                {savedImages.map((image, index) => (
                  //<img key={index} src={image}  style={{ maxWidth: '100px', maxHeight: '100px' }} alt={`Saved ${index}`} />
                  <CheckCircle style={{ fill: '#0072ea' }}/>
                ))}
              </div>


              <label htmlFor="file">
                <div className="item">
                  <img src={Image} alt="" />
                  <span>Aggiungi immagine</span>
                </div>
              </label>


              <div className="item" >
                <img src={Map} alt="" />
                <span onClick={handleLocOpenDialog}>Aggiungi luogo</span>
                <Dialog open={dialogLocOpen} onClose={handleLocCloseDialog}>
                <DialogContent dividers>{
              !isGeolocationAvailable ? (
                <div>
                <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Luogo selezionato</DialogTitle>
                <DialogContent>
                  <MapContainer center={[51.505, -0.09]} zoom={13}>
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                  </MapContainer>
                </DialogContent>
            </div>
            ) : !isGeolocationEnabled ? (
                <div >Geolocalizzazione non attiva</div>
            ) : coords ? (
              <div>
                <DialogTitle>Informativa</DialogTitle>
                <DialogContent>
                    Posizione georiferenziale: Latitudine:{" " + coords.latitude} e Longitudine:{" " + coords.longitude} <br />
                    Confermare per utilizzare la tua posizione.
                    </DialogContent>
                    </div>
                ) : (
                    <div>Prendendo i dati della localizzazione&hellip; </div>
                )}
                </DialogContent>
                <DialogActions>
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={handleLocCloseDialog} color="primary">
                  Cancella
                </Button>
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}}
                  onClick={() => {                  
                      setSelectedLat( coords.latitude);
                      setSelectedLon(coords.longitude);
                      setRimanenti(rimanenti - image_weight);
                      setLocDialogOpen(false); 
                      
                  }}
                  color="primary"
                >
                  Conferma
                </Button>
                </DialogActions>
              </Dialog>
              </div>




              <div className="item">
                <img src={Friend} alt="" />
                <span onClick={handleOpenDialog}>Aggiungi destinatari</span>
                <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="md" fullWidth>
                  <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Seleziona Destinatari</DialogTitle>
                  <DialogContent dividers>
                    <div className="recipient-list">
                      {recipients.map((recipient) => (
                        <div className="recipient-item" key={recipient.email}>
                          <input
                            type="checkbox"
                            onChange={() => handleSelectedRecipient(recipient.email)}
                          />
                          <span> {recipient.email}</span>
                        </div>
                      ))}
                    </div>
                  </DialogContent>
                  <DialogActions>
                    <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={handleCloseDialog} color="primary">
                      Annulla
                    </Button>
                    <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}}
                      onClick={() => {
                        setCategory('privato');
                        setDialogOpen(false);
                      }}
                      color="primary"
                    >
                      Conferma
                    </Button>
                  </DialogActions>
                </Dialog>
              </div>
            </div>
            </div>
          



            <div className="right">
              <IconButton onClick={handleSaveClick} style={{float:"right"}}><SendIcon /></IconButton>
            </div>
            <Dialog open={errorMessage} onClose={handleErrorCloseDialog} maxWidth="md" fullWidth>
              <DialogTitle>Errore! Hai superato il limite dei caratteri! Riduci il messaggio o acquista nuovi caratteri.</DialogTitle>
              <DialogContent dividers>
                <div className="recipient-list">
                <Card sx={{ maxWidth: 345 }}>
                  <CardContent>
                    <Typography gutterBottom variant="h5" component="div">
                      Caratteri
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      <div>
                        Hai raggiunto il limite di caratteri per oggi nel seguente periodo:
                      </div>
                      <div>
                        <strong>Settimana: </strong> Hai utilizzato {userData.charW} caratteri su {userData.CaratteriSettimanali} (limite settimanale)
                      </div>
                      <div>
                        <strong>Mese: </strong> Hai utilizzato {userData.charM} caratteri su {userData.CaratteriMensili} (limite mensile)
                      </div>
                      <div>
                        <strong>Giorno: </strong> Hai utilizzato {userData.charD} caratteri su {userData.CaratteriGiornalieri} (limite giornaliero)
                      </div>
                    </Typography>
                  </CardContent>
                </Card>
                <div style={{paddingTop:"10vh"}}>
                  <Typography gutterBottom variant="h5" component="div">
                    ModalitÃ  d'uso
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <div>
                      Seleziona quale tipo di utilizzo vuoi fare
                    </div>
                    <div>
                      <strong>Privato: </strong> Il messaggio verrÃ  visto solo da te
                    </div>
                    <div>
                      <strong>Pubblico: </strong> Il messaggio verrÃ  visto da tutti i tuoi follower
                    </div>
                  </Typography>
                </div>
                </div>         
              </DialogContent>
              <DialogActions>
                <Button onClick={handleErrorCloseDialog} color="primary">
                  Chiudi
                </Button>
              </DialogActions>
            </Dialog>


            <Dialog open={mentionDialogOpen} onClose={() => setMentionDialogOpen(false)} maxWidth="md" fullWidth>
              <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Menziona un utente</DialogTitle>
              <DialogContent dividers>
                <div className="recipient-list">
                  {potentialMentionetedUser.map((user) => (
                    <div className="recipient-item" key={user.email}>
                      <input
                        type="checkbox"
                        onChange={() => {
                          setSelectedMentioned( user.email);
                        }}
                      />
                      <span>{user.email}</span>
                    </div>
                  ))}
                </div>
              </DialogContent>
              <DialogActions>
              <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={handleMentionConfirm} color="primary">
                  Conferma
                  </Button>
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={() => setMentionDialogOpen(false)} color="primary">
                  Annulla
                </Button>
              </DialogActions>
            </Dialog>



            
            <Dialog open={mentionCanDialogOpen} onClose={() => setMentionCanDialogOpen(false)} maxWidth="md" fullWidth>
              <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Menziona un canale</DialogTitle>
              <DialogContent dividers>
                <div className="recipient-list">
                  {potentialMentionetedCan.map((channel) => (
                    <div className="recipient-item" key={channel.mail}>
                      <input
                        type="checkbox"
                        onChange={() => {
                          setSelectedMentioned(channel.mail);
                         
                        }}
                      />
                      <span>{channel.mail}</span>
                    </div>
                  ))}
                </div>
              </DialogContent>
              <DialogActions>
              <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={() => handleMentionCanConfirm(false)} color="primary">
                  Conferma
                </Button>
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={() => setMentionCanDialogOpen(false)} color="primary">
                  Annulla
                </Button>
              </DialogActions>
            </Dialog>
        </Card>
      </div>
    </div>
  );
};

export default MyPost;