import CardContent from '@mui/material/CardContent';
import $ from 'jquery';
import Typography from '@mui/material/Typography';
import { useEffect } from 'react';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import React from 'react';



const News = () => {

  var currentLink; 

  useEffect(() => {

    const RSS_URL = `http://xml2.corriereobjects.it/rss/homepage.xml`;
    const newsDateElement = document.getElementById("news-date");
    const newsTitleElement = document.getElementById("news-title");

    var newsIndex = 0; // serve per cambiare news dopo 20 secondi
    var listTitle = []; // array di titoli
    var listLink = []; // array di link
    var listDate = []; // array di date
    var globalIndex = 0; // serve per tenere traccia del numero di news totali mostrate, perché dopo 5 giri dello stesso array va aggiornato

    var newsIntervalID; // serve per terminare il conto del setInterval quando deve ripartire dopo 5 giri
    updateNews();


    // funzione che inserisce nella listTitle le notizie prelevate dal feed e richiama il metodo per mostrarle a schermo ogni tot secondi
    function updateNews(){

      // i serve per inserire i titoli nell'array
      var i = 0;
      
      $.ajax(RSS_URL, {
    
        accepts:{
          xml:"application/rss+xml"
        },

        dataType: "xml",

        success:function(data) {
          
          $(data).find("item").each(function () {
    
            var el = $(this);
    
            listTitle[i] = el.find("title").text();
            listDate[i] = el.find("pubDate").text();
            listLink[i] = el.find("link").text();

            i++;
    
          });

          newsTitleElement.innerHTML = listTitle[0];
          newsDateElement.innerHTML = listDate[0];
          currentLink = listLink[0];
    
          // mostra le notizie pgni tot secondi
          newsIntervalID = setInterval(function(){showNews(listTitle)}, 20000);
      
        }	
      });
    
    };

    // funzione che prende in input la listTitle e mostra le news, se l'index arriva oltre alla lunghezza dell'array riparte
    function showNews(listTitle){


      if(newsIndex < listTitle.length){
        
          newsDateElement.innerHTML = listDate[newsIndex];
          newsTitleElement.innerHTML = listTitle[newsIndex];
          currentLink = listLink[newsIndex];
          newsIndex++;

      } else {

          newsIndex = 0;

      }

      // se l'array è stato mostrato tutto 5 volte aggiorna l'array
      if(globalIndex < listTitle.length*5){
        if(newsIndex > 0){
          globalIndex++;
        }
      }else{
        globalIndex = 0;
        newsIndex = 0;
        clearInterval(newsIntervalID);
        updateNews();

      }

    }
  
  }, []);

  const openNewsLink = () => {
    const url = currentLink;
    window.open(url, '_blank');
  };
    
  return (

      <div id='news-feed-page'>

          <Card className='news-container' >

            <CardContent>
              <Typography color="text.secondary" sx={{ fontSize: 14 }}  gutterBottom>
                News Feed Rss
              </Typography>
              <Typography  component="div"  id='news-title' variant="h6"></Typography>
              <Typography id='news-date' variant="body2" ></Typography>

            </CardContent>

            <CardActions>
              <Button color="secondary"  size="small" onClick={openNewsLink} >Scopri di più</Button>
            </CardActions>

          </Card></div>

  );

};

export default News;