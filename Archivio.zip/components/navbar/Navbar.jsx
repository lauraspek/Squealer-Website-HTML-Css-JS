import "./navbar.scss";
import { SlLoop } from "react-icons/sl";
import ExitToAppIcon from '@mui/icons-material/ExitToApp';
import PublicOutlinedIcon from '@mui/icons-material/PublicOutlined';
import NotificationsIcon from '@mui/icons-material/Notifications';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";
import { useState } from 'react';
import React from 'react';
import { Dialog, DialogContent, DialogTitle, Button, Box, AppBar, Toolbar } from "@mui/material";
import '../../client/style.css';
import {IconButton } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import AcquistaCanale from '../../client/AcquistaCanale'
import AcquistaCaratteri from '../../client/AcquistaCaratteri'
import CreaCanalePage from '../../client/CreazioneCanale'
import UtenteInfoPage from '../../client/ProfiloUtente'
import NotificationPage from '../../client/Richieste'
import NewFollow from '../../client/IscrizioneCanale'
import PersonAddAlt1Icon from '@mui/icons-material/PersonAddAlt1';
import AddBoxIcon from '@mui/icons-material/AddBox';  
import ShoppingCartOutlinedIcon from '@mui/icons-material/ShoppingCartOutlined';


const Navbar = () => {
  const [openDialog, setOpenDialog] = React.useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [modalCarello, setCarelloVisible] = useState(false);
  const [modalNewPage, setNewPageVisible] = useState(false);
  const [modalNotification, setNotificatioVisible] = useState(false);
  const [modalNewFollower, setNewFollowerVisible] = useState(false);
  const [modalPerson, setPersonVisible] = useState(false);
  const [modalCanale, setCanaleVisible] = useState(false);
  
  const handleRefresh = () => { 
    localStorage.setItem('reloadPage',true);
    window.location.reload();

};

    
  const handleToggleModal = (modalId) => {
    switch (modalId) {
      case 'carello1':
        setCarelloVisible(!modalCarello);
        setNewFollowerVisible(false);
        setPersonVisible(false);
        setNewPageVisible(false);
        setNotificatioVisible(false);
        setCanaleVisible(false);

        break;
        case 'newFollower':
          setNewFollowerVisible(!modalNewFollower);
          setPersonVisible(false);
          setNewPageVisible(false);
          setNotificatioVisible(false);
          setCarelloVisible(false);
          setCanaleVisible(false);
          break;
          case 'infoPerson':
            setPersonVisible(!modalPerson);
            setNewPageVisible(false);
            setNotificatioVisible(false);
            setCarelloVisible(false);
            setNewFollowerVisible(false);
            setCanaleVisible(false);

          break;
          case 'newPage':
            setNewPageVisible(!modalNewPage);
            setNotificatioVisible(false);
            setCarelloVisible(false);
            setNewFollowerVisible(false);
            setPersonVisible(false);
            setCanaleVisible(false);

          break;
          case 'notification':
            setNotificatioVisible(!modalNotification);
            setCarelloVisible(false);
            setNewFollowerVisible(false);
            setPersonVisible(false);
            setNewPageVisible(false);
            setCanaleVisible(false);


          break;
          case 'carelloCanale':
            setCanaleVisible(!modalCanale);
            setCarelloVisible(false);
            setNewFollowerVisible(false);
            setPersonVisible(false);
            setNewPageVisible(false);
            setNotificatioVisible(false);


          break;

                default:
        break;
    }
  };


  function handleGoBack() {
    localStorage.setItem('reloadPage',false);
    localStorage.setItem('email',"");
    localStorage.setItem('password',"");
    localStorage.setItem('userType',"");
    localStorage.setItem('name',"");
    localStorage.setItem('surname',"");
    window.location.reload();   //dovrebbe andare nella firspage

  }

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  

  function handleOpenDialog() {
    setOpenDialog(true);
  }

  return (
    <div>
      <Box id="boxTotal" >
          <Toolbar className="mod-header-bar"style={{ width:"100%",height:"70%", backgroundColor:"trasparent" }}>
            <Box className="boxIconRight" sx={{ '& > :not(style)': {m: 2,}, width: "20vw",height:"100vh" ,position:"relative",top:"10vh",right:"0vh"}}>
            
            <Button id="btnInfoPerson" onClick={() => handleToggleModal('infoPerson')}>
                <AccountCircleOutlinedIcon id="iconPerson" />   
                <h3 id="personTxt">Il mio profilo</h3>
                </Button>
              
              <Button id="btnNewFollower" onClick={() => handleToggleModal('newFollower')}>
                <PersonAddAlt1Icon id="addPerson" />
                <h3 id="newFollowerTxt">Aggiungi follower</h3>
                </Button>

              <Button id="btnNotification" onClick={() => handleToggleModal('notification')}>
                <NotificationsIcon id="notificationIcon"/>
                <h3 id="notificationTxt">Notifiche</h3>
                </Button>


                <Button id="btnNewPage" onClick={() => handleToggleModal('newPage')}>
                <AddBoxIcon id="createCanalPage" />
                <h3 id="createCanalTxt">Crea un nuovo canale</h3>
                </Button>

            
              <Button id="btnLogout" onClick={handleGoBack}>
                <ExitToAppIcon id="logOutIcon" />
                <h3 id="logOutTxt">Logout</h3>
              </Button>

              <Button id="btnRefresh" onClick={handleRefresh}>
                <SlLoop  id="refreshIcon" />
                <h3 id="refreshTxt">Refresh</h3>
              </Button>

              <Button id="btnGrid" onClick={() => handleToggleModal('carello1')}>
                <ShoppingCartOutlinedIcon id="GridIcon" />
                <h3 id="GridTxt">Acquista caratteri</h3>
              </Button>

              <Button id="btnCanale" onClick={() => handleToggleModal('carelloCanale')}>
                <PublicOutlinedIcon id="CanaleIcon" />
                <h3 id="CanaleTxt">Compra Canale</h3>
              </Button>
            </Box>

              <IconButton
                size="large"
                edge="start"
                color="inherit"
                aria-label="menu"
                sx={{
                  mr: 2,
                  display: { sm: 'none', xs: 'block' },
                  padding: '0px !important',
                  marginRight: '0px !important',
                  marginLeft: '16px !important'
                }}
                className="menuButton"
                onClick={handleDrawerToggle}
              >
                <MenuIcon />
            </IconButton>

          </Toolbar>
      </Box>


      <Dialog open={openDialog}>
        <DialogTitle>Cosa vuoi Acquistare?</DialogTitle>

        <DialogContent sx={{ '& button': { m: 1 } }}>
          <Link to="/AcquistaCaratteri">
            <Button
              variant="contained"
              color="secondary"
            >Caratteri</Button>
          </Link>

          <Link to="/AcquistaCanale">
            <Button
              variant="contained"
              color="secondary"
            >Canali</Button>
          </Link>
        </DialogContent>
      </Dialog>

      {modalCarello && (
      <div className="modal">
          <AcquistaCaratteri handleClick={() => handleToggleModal('carello1')}></AcquistaCaratteri>
      </div>
      )}

      {modalNewPage && (
      <div className="modal">
          <CreaCanalePage handleClick={() => handleToggleModal('newPage')}></CreaCanalePage>
      </div>
      )}
      {modalNotification && (
      <div className="modal">
          <NotificationPage handleClick={() => handleToggleModal('notification')}></NotificationPage>
      </div>
      )}
      {modalPerson && (
      <div className="modal">
          <UtenteInfoPage handleClick={() => handleToggleModal('infoPerson')}></UtenteInfoPage>
      </div>
      )}
      {modalNewFollower && (
      <div className="modal">
          <NewFollow handleClick={() => handleToggleModal('newFollower')}></NewFollow>
      </div>
      )}
          
         {modalCanale && (
      <div className="modal">
          <AcquistaCanale handleClick={() => handleToggleModal('carelloCanale')}></AcquistaCanale>
      </div>
      )}
    </div>
    


  );
};

export default Navbar;