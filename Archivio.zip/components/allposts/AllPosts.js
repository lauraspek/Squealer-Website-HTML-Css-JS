import Post from "../post/Post";
import "./allposts.scss";
import React from 'react';
import { useEffect } from 'react';
import axios from 'axios';

const AllPosts = () => {
  const utenteMail = localStorage.getItem('email');
  const [posts1, setPosts] = React.useState([]); 
  
  useEffect(() => {
    axios
      .get('http://localhost:3001/get/messaggiUtente/'+ utenteMail)
      .then((response) => {
        setPosts(response.data);
        console.log(response.data);
        console.log(posts1);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);

  return (
  <div className="posts">    
    {
    posts1.map(post => 
      
      <Post post={post} key={post.id}/>
    )  
    }
  </div>
  );

};

export default AllPosts;
