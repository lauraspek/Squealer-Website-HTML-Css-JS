import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { styled } from '@mui/material/styles';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import {Button,Card,Collapse,Dialog,DialogContent,DialogTitle,IconButton,TextField,Avatar,Chip,Stack,} from '@mui/material';
import {FavoriteBorderOutlined as FavoriteBorderOutlinedIcon,ThumbDownAlt as ThumbDownAltIcon,FavoriteOutlined as FavoriteOutlinedIcon,MoreHoriz as MoreHorizIcon,ThumbDownOffAlt as ThumbDownOffAltIcon,Notes as NotesIcon,} from '@mui/icons-material';
import 'leaflet/dist/leaflet.css';
import { makeStyles } from '@mui/styles';
import './post.scss';
import markerIconPng from "leaflet/dist/images/marker-icon.png"
import {Icon} from 'leaflet'
import DialogActions from '@mui/material/DialogActions';
import { MapRounded, ImageRounded   } from '@mui/icons-material';
import { MapContainer, Marker, TileLayer, Popup } from 'react-leaflet'; 

const useStyles = makeStyles((theme) => ({
  card: {width: '90vw',padding: '5vh',borderRadius: '10px',[theme.breakpoints.down('sm')]: {padding: '0vh', margin: '0vh', width: '85%',},
  },
  cardComment: {width: '95%',padding: '5vh',margin: '5vh',textAlign:'left',[theme.breakpoints.down('sm')]: {padding: '0vh', margin: '0vh', width: '85%',},
  },
  MapContainer:{width: '95%',height: '80vh',padding: '5vh',margin: '5vh',[theme.breakpoints.down('sm')]: {padding: '0vh',margin: '0vh',width:'73vw',height:'50vh',marginTop: '2vh',},
  },
  dialog:{width: '100vw',height: '100vh',padding: '25vh',textAlign: 'center',[theme.breakpoints.down('sm')]: {padding: '7vh',width: '100vw',height: '100vh',},
  },
  label:{width:'40vw',},
  stack:{marginLeft:'12vw', marginTop:'5vh',[theme.breakpoints.down('sm')]: {marginLeft:'0vw', marginTop:'2vh',},
  },
}));

const Post = ({ post }) => {
  const [reactionPos, setReactionPos] = useState(0);
  const [reactionNeg, setReactionNeg] = useState(0);
  const postDate = new Date(post.data);
  const [liked, setLiked] = useState(false);
  const [unLiked, setUnLiked] = useState(false);
  const [showComments, setShowComments] = useState(false);
  const [openCommentDialog, setOpenCommentDialog] = useState(false);
  const [comment, setComment] = useState("");
  const [showItemP, setShowItemP] = useState(false);
  const [showItemU, setShowItemU] = useState(false);
  const [showItemC, setShowItemC] = useState(false);
  const [comments, setComments] = useState([]);
  const [position,setPosition] = useState();
  const [imageCheck,setImageCheck] = useState();


  const ExpandMore = styled((props) => {
   
  const { expand, ...other } = props;
    return <IconButton {...other} />;
  })(({ theme, expand }) => ({transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',marginLeft: 'auto',transition: theme.transitions.create('transform', {duration: theme.transitions.duration.shortest,}),
  }));

  const formatDate = (date) => {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const handleShowComments = () => {
    setShowComments(!showComments);
  };


  const classes = useStyles();

  const images = 'http://localhost:3000/saved/';


  useEffect(() => {
    calculatePopularity(reactionPos, reactionNeg);
  }, [reactionPos, reactionNeg]);



  useEffect(() => {
    axios.get(`http://localhost:3001/get/commenti/${post.id}`)
      .then((response) => {
        setComments(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API dei commenti:", error);
      });
  }, [post.id]);


  useEffect(() => {
    axios.get(`http://localhost:3001/get/reazioniPos/${post.id}`)
      .then((response) => {
        setReactionPos(response.data[0].count);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });


    axios.get(`http://localhost:3001/get/reazioniNeg/${post.id}`)
      .then((response) => {
        setReactionNeg(response.data[0].count);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);


  const handleOpenDialogComments = () => {
    setOpenCommentDialog(true);
  };

  const email = localStorage.getItem('email');

  const handleAddComment = () => {
    const requestBody = {
      idMessaggio: post.id,
      emailMittente: email,
      emailDestinatario:post.mittente,
      testo: comment,
    };


    axios.post('http://localhost:3001/aggiungiCommento', requestBody)
      .then((response) => {
        setOpenCommentDialog(false);
      })
      .catch((error) => {
        console.error('Errore durante la richiesta API:', error);
      });

        localStorage.setItem('reloadPage',true);
        window.location.reload();
  };

  const handleAddUnlike = () => {
    if (!unLiked) {
      const requestBody = {
        idMessaggio: post.id, 
        email: email,
      };
      console.log(requestBody);
      axios.post(`http://localhost:3001/post/ReazioneNegativa`, requestBody)
        .then((response) => {
          setReactionNeg(reactionNeg + 1);
          setUnLiked(true);
        })
        .catch((error) => {
          console.error("Errore durante la richiesta API:", error);
        });
    } 
  };

  const handlePositioning = () =>{
      setPosition(true);
  }

  const handleImage = () =>{
    setImageCheck(true);
}

  const onConfirm = () =>{
    setPosition(false);
}

const onConfirmImage = () =>{
  setImageCheck(false);
}
  const handleAddLike = () => {
    if (!liked) {
      const requestBody = {
        idMessaggio: post.id, 
        email: email, 
      };
      console.log(requestBody);
      axios.post(`http://localhost:3001/post/ReazionePositiva/`, requestBody)
        .then((response) => {
          setReactionPos(reactionPos + 1);
          setLiked(true);
        })
        .catch((error) => {
          console.error("Errore durante la richiesta API:", error);
        });
    } 


  };

  const calculatePopularity = (pos, neg) => {
    if (pos - neg > 0) {
      setShowItemP(true);
      setShowItemU(false);
      setShowItemC(false);
    } else if (pos - neg === 0) {
      setShowItemP(false);
      setShowItemU(false);
      setShowItemC(true);
    } else if (pos - neg < 0) {
      setShowItemP(false);
      setShowItemU(true);
      setShowItemC(false);
    }
  };


  const isPublicCategory = post.categoria === 'pubblico';
  const IsPosition = (post.latitude === 0) && (post.longitude === 0);

  return (
    <div className="post">
      <Card className={classes.card} style={{borderRadius: '0'}}>
        <div className="container">
          <div className="user">
            <div className="userInfo">
              {post?.foto ? (
                <img src={post.foto} alt="" />
              ) : (
                <Avatar aria-label="recipe" style={{width:'12vh',height:'6vh', borderRadius:'0', position:'relative', right:'6vh', bottom:'1vh'}}>
                  {post.nome}
                </Avatar>
              )}
              <div className="details" style={{position:'relative', right:'4vh'}}>

                  <span className="name">{post?.mittente}</span>
                <span className="date">{formatDate(postDate)}</span>
              </div>
            </div>
            
            <ExpandMore
              expand={showComments}
              onClick={handleShowComments}
              aria-showComments={showComments}
              aria-label="show more"
              id="ExpandMoreIcon"
            >
              <ExpandMoreIcon />
            </ExpandMore>
          </div>
          <div className="content">
            <p>{post?.testo}</p>          
            {post?.immagine && <img src={post.immagine} alt="" />}
          </div>



          <div style={{position:'relative', top:'9vh'}} className="info">
          {isPublicCategory && (
            <div className="item" onClick={handleAddLike}>
              {liked ? (
                <FavoriteOutlinedIcon  />
              ) : (
                <FavoriteBorderOutlinedIcon />
              )}
              {reactionPos}
            </div>)}

            
                <div>
                  <NotesIcon
                  onClick={handleOpenDialogComments}
                  />
                </div>
              

                {isPublicCategory && (
            <div className="item" onClick={handleAddUnlike}>
              {unLiked ? (
                <ThumbDownAltIcon />
              ) : (
                <ThumbDownOffAltIcon />
              )}
              {reactionNeg}
          </div>)}
          
          <div className="item" > 
                
          {IsPosition ? (
               <MapRounded  onClick={handlePositioning}/>
              ) : (
                <MapRounded style={{ fill: '#00FF00' }} onClick={handlePositioning}/>
              )}
              </div>

          {post.immagine != null ? (
                <ImageRounded style={{ fill: '#0072ea' }} onClick={handleImage}/>
              ) : (
                <ImageRounded disabled/>
              )}


<Dialog open={imageCheck}>
      <DialogTitle>immagine</DialogTitle>
      <DialogContent>
          <img  src={images +post.immagine}  style={{ width: '50vh', height: '50vh' }} alt={`img`} />
            </DialogContent>
      <DialogActions>
        <Button onClick={onConfirmImage} color="primary">
          Conferma
        </Button>
      </DialogActions>
    </Dialog>

          <Dialog open={position}>
      <DialogTitle>Posizione</DialogTitle>
      { !IsPosition ? (
      <DialogContent>
            <MapContainer center={[post.latitude, post.longitude]} zoom={15} style={{ width: '40vh', height: '40vh' }}>
                    <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                    <Marker position={[post.latitude, post.longitude]} icon={new Icon({iconUrl: markerIconPng, iconSize: [25, 41], iconAnchor: [12, 41]})} >
                        <Popup>
                          My position {post.latitude} e {post.longitude}
                        </Popup>
                   </Marker>
            </MapContainer>
      </DialogContent>
      )  : (
        <DialogContent>
          Posizione georiferenziale non è stata condivisa<br />        
        </DialogContent>
      )}
      <DialogActions>
        <Button onClick={onConfirm} color="primary">
          Conferma
        </Button>
      </DialogActions>
    </Dialog>

            </div>

            <div className="item" style={{marginBottom:'1vh'}} >
              <Chip style={{ width:'20vh',position:'relative', left:'60vh', borderRadius:'0', padding:'2vh' }} label={post.categoria} color="primary" >{post.categoria}</Chip>
            </div>

            {isPublicCategory ? (
              <div>
                {showItemP && (
                  <div className="item">
                    <Chip style={{ backgroundColor: 'green', width: '20vh', position: 'relative', left: '60vh', borderRadius: '0',  padding: '2vh' }} label={"popolare"} color="primary">
                    </Chip>
                  </div>
                )}
                {showItemU && (
                  <div className="item">
                    <Chip style={{ backgroundColor: 'red', width: '20vh', position: 'relative', left: '60vh', borderRadius: '0', padding: '2vh' }} label={"impopolare"} color="primary">
                    </Chip>
                  </div>
                )}
                {showItemC && (
                  <div className="item">
                    <Chip style={{ backgroundColor: 'orange', width: '20vh', position: 'relative', left: '60vh', borderRadius: '0',  padding: '2vh' }} label={"controverso"} color="primary">
                      
                    </Chip>
                  </div>
                )}
              </div>
            ) : (
              
                <div className="item">
                  <Chip style={{ backgroundColor: 'green', width: '20vh', position: 'relative', left: '60vh', borderRadius: '0', padding: '2vh' }} label={post.destinatario} color="primary">
                  </Chip>
                </div>
            )}
            
            </div>
          
          <Collapse in={showComments} timeout="auto" unmountOnExit>
            
              {comments.map((comment) => (
                  <List>
                      <ListItem>
                        <ListItemText primary={comment.Commentatore} secondary={comment.testo}/>
                      </ListItem>
                      <Divider />
                    </List>
              ))}
            
          </Collapse>
      </Card>

      <Dialog className={classes.dialog} open={openCommentDialog}>
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Aggiungi Commento:</DialogTitle>
        <DialogContent>
          <TextField
            variant='outlined'
            value={comment}
            label="Commento"
            className={classes.label}
            onChange={(e) => setComment(e.target.value)}
            style={{marginTop:'2vh',width:'50vh'}}
          />
           <Stack  className={classes.stack} direction="row" style={{margin:'1vh 9vh 1vh 9vh'}} spacing={2}>
            <Button style={{background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={handleAddComment} variant="contained" color="secondary">Aggiungi</Button>
            <Button style={{background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', color:'white'}} onClick={() => setOpenCommentDialog(false)} variant="contained" color="secondary">Annulla</Button>
          </Stack>
        </DialogContent>
      </Dialog>
    </div>
  );
}; export default Post;

           
         