import React from 'react';
import axios from 'axios';
import FirstPage from './PaginaIniziale';
import './style.css';
import Login from "./Login";
import Home from './Homepage';
import { useState } from 'react';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

const SignUp = () => {
  const [goBack, setGoBack] = React.useState(false);
  const [userExists, setUserExists] = useState(false);
  const [goToLogin, setGoToLogin] = React.useState(false);
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [name, setName] = React.useState('');
  const [surname, setSurname] = React.useState('');

  function handleGoBack(){
    setGoBack(true);
  }

  function showLogIn(){
    setGoToLogin(true);
  }

  if (goBack) {
    return (
      <div>
        <FirstPage/>
      </div>
    );
  }

  if (userExists) {
    return (
      <div>
        <Home/>
      </div>
    );
  }

  if (goToLogin) {
    return (
      <div>
        <Login/>
      </div>
    );
}


const handleSignUp = async (e) => {
  e.preventDefault();
  try {

    if (!username || !password || !name || !surname) {
      alert("Per favore, compila tutti i campi.");
      return;
    }
    const response = await axios.get('http://localhost:3001/api/get')     //prendo tutti gli utenti
    const userList = response.data;
    let userExists;
    if( userExists = userList.some((utente) => utente.mail === username)){
      alert("Utente già registrato");
    }else{
    
      try {
        const response = await axios.post('http://localhost:3001/post/utenti', {      //inserisce l'utente nel db
          username,
          password,
          name,
          surname,
        });

        setUserExists(userExists);
      } catch (error) {
        console.error(error);
      }
      alert("Registrazione avuta con successo");
      showLogIn();
    }     
  } catch (error) {
    console.error(error);
  }
};

  return (
      <div id="container">

        <div className="form-container" >

          <div id='form-logo'></div>

          <div onClick={handleGoBack} id="btn-form-exit" ><HighlightOffIcon size={20} sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} /></div>

          <h2 id="titleSignin">SIGN UP</h2>

          <form id="signup-form" onSubmit={handleSignUp} >

            <input className="input-field"  name="username" id="username" placeholder="Email" type="text" value={username} onChange={(e) => setUsername(e.target.value)}/>

            <input className="input-field" id="name" type="text" name="name"  placeholder="Nome" value={name} onChange={(e) => setName(e.target.value)}/>

            <input className="input-field" name="surename" type="text" id="surename" placeholder="Cognome" value={surname} onChange={(e) => setSurname(e.target.value)}/>

            <input className="input-field"  name="password" id="password" placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)}/>

            <div id="form-btn-container">
              <button type="submit" className="btnSignUp" >SIGNUP</button>
              <p>Possiedi già un account? <a onClick={showLogIn}>Accedi</a></p>
            </div>
           
          </form></div></div>
  );
};

export default SignUp;

