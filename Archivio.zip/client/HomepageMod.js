import { BottomNavigation, BottomNavigationAction, Button } from "@mui/material"; 
import '../immagini/lol3.png'; 
import RssFeedIcon from '@mui/icons-material/RssFeed'; 
import HomeRoundedIcon from '@mui/icons-material/HomeRounded'; 
import VisualizzaSquealMod from "./VisualizzaSquealMod"; 
import CanaliPubblici from "./GestioneCanaliMod"; 
import InfoRoundedIcon from '@mui/icons-material/InfoRounded'; 
import FirstPage from "./PaginaIniziale"; 
import Diversity2Icon from '@mui/icons-material/Diversity2'; 
import React, { useState } from "react"; 
import ImpostazioniModeratore from "./ProfiloModeratore"; 
import UsersPage from "./GestioneUtentiMod"; 
import './style.css'; 
import { Box, Divider, Toolbar, Link as RouterLink } from "@mui/material"; 
import PeopleAltRoundedIcon from '@mui/icons-material/PeopleAltRounded'; 

 
const HomepageMod = (props) => { 
    const [modalVisualizzaSquealer, setVisualizzaSquealer] = useState(false); 
    const [modalUsersPage, setUsersPage] = useState(false); 
    const [modalImpostazioniModeratore, setImpostazioniModeratore] = useState(false);     
    const [modalCanaliPubblici, setCanaliPubblici] = useState(false);   
    const [goBack, setGoBack] = useState(false); 

 
    const handleToggleModal = (modalId) => { 
        switch (modalId) { 
            case 'VisualizzaSquealer': 
                setVisualizzaSquealer(!modalVisualizzaSquealer); 
                setCanaliPubblici(false); 
                setUsersPage(false); 
                setImpostazioniModeratore(false); 
              break; 
              case 'CanaliPubblici': 
                setCanaliPubblici(!modalCanaliPubblici); 
                setUsersPage(false); 
                setImpostazioniModeratore(false); 
                setVisualizzaSquealer(false); 
 
              break; 
              case 'UsersPage': 
                setUsersPage(!modalUsersPage); 
                setImpostazioniModeratore(false); 
                setVisualizzaSquealer(false); 
                setCanaliPubblici(false); 
              break; 
              case 'ImpostazioniModeratore': 
                setImpostazioniModeratore(!modalImpostazioniModeratore); 
                setVisualizzaSquealer(false); 
                setCanaliPubblici(false); 
                setUsersPage(false); 
 
              break; 
              case 'Home': 
              setImpostazioniModeratore(false); 
              setVisualizzaSquealer(false); 
              setCanaliPubblici(false); 
              setUsersPage(false); 

            break;
            default: 
            break; 
        } 
      }; 
     
       


 
    const handleLogOut = () => { 
        localStorage.setItem('reloadPage',false);
        localStorage.setItem('email',"");
        localStorage.setItem('password',"");
        localStorage.setItem('userType',"");
        localStorage.setItem('name',"");
        localStorage.setItem('surname',"");
        window.location.reload();
        setGoBack(true); 
    }; 
 

 
 
    if(goBack){ 
        return( 
            <div> 
               <FirstPage /> 
            </div> 
        ) 
    } 
 
    return ( 
        <div> 
 
                <div id="logoApp"></div> 
                <p><h2 id="titleModerator">SQUEALER</h2></p> 
 
 
 
            <Box> 
                    <Toolbar className="vip-header-bar"><div className="mod-header-logo"></div> 
 
 <Box sx={{ position: 'absolute', top: 0, right: 0, margin: '10px' }}> 
     <Button   
     onClick={handleLogOut}  
     color='secondary' 
     variant='contained' 
     style={{marginTop:'2vh',color:'white',  background: 'linear-gradient(to left, #000000, #5e071a)', height:'7vh', fontWeight: 'bold' }} >Logout</Button> 
 </Box> 
</Toolbar> 
</Box> 



<Divider /> 

<BottomNavigation 
value={0} 
onChange={(event, newValue) => { 
switch (newValue) { 
 case 0: 
     handleToggleModal('Home'); 
     break; 
 case 1: 
     handleToggleModal('UsersPage'); 
     break; 
 case 2: 
     handleToggleModal('VisualizzaSquealer'); 
     break; 
 case 3: 
     handleToggleModal('CanaliPubblici'); 
     break; 
 case 4: 
     handleToggleModal('ImpostazioniModeratore'); 
     break; 
 default: 
     break; 
} 
}} 
showLabels 
sx={{ position: 'fixed', bottom: 0, width: '100%', bgcolor: '#5e071a', color: 'white',  height: '11vh', 
'& .Mui-selected': { 
color: 'white',  
}, 
'& .MuiBottomNavigationAction-label': { 
color: 'white',  
}, 
}} 
> 
<BottomNavigationAction label="Home" icon={<HomeRoundedIcon style={{ color: 'white' }} />} /> 
<BottomNavigationAction label="Utenti" icon={<PeopleAltRoundedIcon style={{ color: 'white' }}/>} /> 
<BottomNavigationAction label="Squeal" icon={<RssFeedIcon style={{ color: 'white' }}/>} /> 
<BottomNavigationAction label="Canali Pubblici" icon={<Diversity2Icon style={{ color: 'white' }}/>} /> 
<BottomNavigationAction label="Profilo" icon={<InfoRoundedIcon style={{ color: 'white' }}/>} /> 
</BottomNavigation> 



{/* //modali */} 
{modalVisualizzaSquealer && ( 
<div className="modal"> 
<VisualizzaSquealMod  handleClick={() => handleToggleModal('VisualizzaSquealer')}></VisualizzaSquealMod> 
</div> 
)} 
{modalCanaliPubblici && ( 
<div className="modal"> 
<CanaliPubblici  handleClick={() => handleToggleModal('CanaliPubblici')}></CanaliPubblici > 
</div> 
)} 
{modalUsersPage && ( 
<div className="modal"> 
<UsersPage  handleClick={() => handleToggleModal('UsersPage')}></UsersPage> 
</div> 
)} 
{modalImpostazioniModeratore && ( 
<div className="modal"> 
<ImpostazioniModeratore  handleClick={() => handleToggleModal('ImpostazioniModeratore')}></ImpostazioniModeratore> 
</div> 
)} 




</div> 
); 
}; 

export default HomepageMod;