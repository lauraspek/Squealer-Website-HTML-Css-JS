import React, { useEffect, useState } from "react";
import PropTypes from 'prop-types';
import { styled } from '@mui/material/styles';
import Stack from '@mui/material/Stack';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Check from '@mui/icons-material/Check';
import SettingsIcon from '@mui/icons-material/Settings';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import VideoLabelIcon from '@mui/icons-material/VideoLabel';
import StepConnector, { stepConnectorClasses } from '@mui/material/StepConnector';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { IconButton } from '@mui/material';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardActionArea from '@mui/material/CardActionArea';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import axios from 'axios';
import Home from './Home';
import CloseIcon from '@mui/icons-material/Close';

const QontoConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 10,
    left: 'calc(-50% + 16px)',
    right: 'calc(50% + 16px)',
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: '#784af4',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: '#784af4',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    borderColor: theme.palette.mode === 'dark' ? theme.palette.grey[800] : '#eaeaf0',
    borderTopWidth: 3,
    borderRadius: 1,
  },
}));

const QontoStepIconRoot = styled('div')(({ theme, ownerState }) => ({
  color: theme.palette.mode === 'dark' ? theme.palette.grey[700] : '#eaeaf0',
  display: 'flex',
  height: 22,
  alignItems: 'center',
  ...(ownerState.active && {
    color: '#784af4',
  }),
  '& .QontoStepIcon-completedIcon': {
    color: '#784af4',
    zIndex: 1,
    fontSize: 18,
  },
  '& .QontoStepIcon-circle': {
    width: 8,
    height: 8,
    borderRadius: '50%',
    backgroundColor: 'currentColor',
  },
}));

function QontoStepIcon(props) {
  const { active, completed, className } = props;
  return (
    
    <QontoStepIconRoot ownerState={{ active }} className={className}>
      {completed ? (
        <Check className="QontoStepIcon-completedIcon" />
      ) : (
        <div className="QontoStepIcon-circle" />
      )}
    </QontoStepIconRoot>
  );
}

QontoStepIcon.propTypes = {
  active: PropTypes.bool,
  className: PropTypes.string,
  completed: PropTypes.bool,
};

const ColorlibConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor:
      theme.palette.mode === 'dark' ? theme.palette.grey[800] : '#eaeaf0',
    borderRadius: 1,
  },
}));

const ColorlibStepIconRoot = styled('div')(({ theme, ownerState }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? theme.palette.grey[700] : '#ccc',
  zIndex: 1,
  color: '#fff',
  width: 50,
  height: 50,
  display: 'flex',
  borderRadius: '50%',
  justifyContent: 'center',
  alignItems: 'center',
  ...(ownerState.active && {
    backgroundImage:
      'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
    boxShadow: '0 4px 10px 0 rgba(0,0,0,.25)',
  }),
  ...(ownerState.completed && {
    backgroundImage:
      'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
  }),
}));

function ColorlibStepIcon(props) {
  const { active, completed, className } = props;

  const icons = {
    1: <SettingsIcon />,
    2: <GroupAddIcon />,
    3: <VideoLabelIcon />,
  };

  return (
    <ColorlibStepIconRoot ownerState={{ completed, active }} className={className}>
      {icons[String(props.icon)]}
    </ColorlibStepIconRoot>
  );
}

ColorlibStepIcon.propTypes = {
  active: PropTypes.bool,
  className: PropTypes.string,
  completed: PropTypes.bool,
  icon: PropTypes.node,
};

const steps = ['Visualizza Canali', 'Seleziona Canali da acquistare', 'Conferma pagamento'];

export default function CustomizedSteppers() {
  const [activeStep, setActiveStep] = React.useState(0);
  const [userData, setUserData] = useState([]);
  const [selectedChannels, setSelectedChannels] = useState([]);
  const [totalCost, setTotalCost] = useState(0);
  const [exitBtn, setExitBtn] = React.useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:3001/get/canaliMinSquealer")
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);

  const handleNext = () => {
    if (activeStep === 1) {
      const checkboxes = document.querySelectorAll('input[type="checkbox"]');
      const selected = Array.from(checkboxes).filter((checkbox) => checkbox.checked);
      const selectedChannelNames = selected.map((checkbox) => checkbox.value);
      setSelectedChannels(selectedChannelNames);
      const total = selectedChannelNames.length * 20;
      setTotalCost(total);
    }
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const acquirente = localStorage.getItem('email');

  const handleReset = async (e) => {

    setActiveStep(0);
    setSelectedChannels([]);
    setTotalCost(0);
  
    if (selectedChannels.length === 0) {
      alert("Seleziona almeno un canale prima di inviare la richiesta di acquisto.");
      return; // Interrompi la funzione se l'array selectedChannels è vuoto.
    }

    try {
      const response = await axios.post(`http://localhost:3001/post/richiestaAcquisto/${acquirente}`, {
        canale: selectedChannels,
      });
      console.log('Risposta dalla stored procedure:', response.data);
      alert("Richiesta di acquisto effettuata correttamente");
    } catch (error) {
      console.error(error);
    } 

  };
 
  const handleExitBtn = () => {
    setExitBtn(true);
  };


  if (exitBtn) {
    return (
      <div>
        <Home />
      </div>
    );
  }

  return (
    <div>

      <div id="divCloseWindow" onClick={handleExitBtn}>
        <CloseIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>
    
   
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>

      <Stack sx={{ width: '100%' }} spacing={4}>

        <Stepper  alternativeLabel activeStep={activeStep} connector={<QontoConnector />}>
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel StepIconComponent={QontoStepIcon} id="carrello-step-label">{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <Stepper alternativeLabel activeStep={activeStep} connector={<ColorlibConnector /> } >
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel StepIconComponent={ColorlibStepIcon} id="carrello-step-label">{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

        <div id="carrello-riepilogo">

          {activeStep === 0 && (
            <Card sx={{ display: 'flex', justifyContent: 'center', width:'90%'}}>
              <CardActionArea>
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Canali Disponibili:
                  </Typography>
                  {userData.map((channel, index) => (
                    <Typography key={index} variant="body2" color="text.secondary">
                      {channel.nome}
                    </Typography>
                  ))}
                </CardContent>
              </CardActionArea>
            </Card>
          )}

          {activeStep === 1 && (
            <Card sx={{  display: 'flex', justifyContent: 'center', width:'90%'}}>
              <CardActionArea>
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Seleziona canali da acquistare:
                  </Typography>
                  {userData.map((channel, index) => (
                    <div key={index}>
                      <label>
                        <input type="checkbox" name={`channel-${index}`} value={channel.nome} />
                        {channel.nome}
                      </label>
                    </div>
                  ))}
                </CardContent>
              </CardActionArea>
            </Card>
          )}

          {activeStep === 2 && (
            <Card sx={{  display: 'flex', justifyContent: 'center', width:'90%'}}>
              <CardActionArea>
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Riepilogo:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Canali selezionati:
                    <ul>
                      {selectedChannels.map((channel, index) => (
                        <li key={index}>{channel}</li>
                      ))}
                    </ul>
                    Costo totale: {totalCost} euro
                  </Typography>
                  <Button variant="contained" color="secondary" onClick={handleReset}>
                    Conferma
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          )}
        </div>
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <IconButton disabled={activeStep === 0} onClick={handleBack}>
            <ArrowBackIosIcon style={{ color: 'white' }} />
          </IconButton>
          <IconButton disabled={activeStep === steps.length - 1} onClick={handleNext}>
            <ArrowForwardIosIcon style={{ color: 'white' }} />
          </IconButton>
        </div>
      </Stack>
    </div>
    </div>
  );
}
