import * as React from 'react';
import axios from 'axios';
import { useEffect } from 'react';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import CloseIcon from '@mui/icons-material/Close';

import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';

import StepConnector, { stepConnectorClasses } from '@mui/material/StepConnector';

import FormControl from '@mui/material/FormControl';
import { useState } from 'react';

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import { Alert } from '@mui/material';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import Check from '@mui/icons-material/Check';
import PropTypes from 'prop-types';
import SettingsIcon from '@mui/icons-material/Settings';
import VideoLabelIcon from '@mui/icons-material/VideoLabel';
import Home from './Home';
import CardActionArea from '@mui/material/CardActionArea';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import OpenInFullIcon from '@mui/icons-material/OpenInFull';



const QontoStepIconRoot = styled('div')(({ theme, ownerState }) => ({
  color: theme.palette.mode === 'dark' ? theme.palette.grey[700] : '#eaeaf0',
  display: 'flex',
  height: 22,
  alignItems: 'center',
  ...(ownerState.active && {
    color: '#784af4',
  }),
  '& .QontoStepIcon-completedIcon': {
    color: '#784af4',
    zIndex: 1,
    fontSize: 18,
  },
  '& .QontoStepIcon-circle': {
    width: 8,
    height: 8,
    borderRadius: '50%',
    backgroundColor: 'currentColor',
  },
}));

function QontoStepIcon(props) {
  const { active, completed, className } = props;
  return (
    
    <QontoStepIconRoot ownerState={{ active }} className={className}>
      {completed ? (
        <Check className="QontoStepIcon-completedIcon" />
      ) : (
        <div className="QontoStepIcon-circle" />
      )}
    </QontoStepIconRoot>
  );
}

QontoStepIcon.propTypes = {
  active: PropTypes.bool,
  className: PropTypes.string,
  completed: PropTypes.bool,
};

const ColorlibConnector = styled(StepConnector)(({ theme }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 22,
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      backgroundImage:
        'linear-gradient( 95deg,rgb(242,113,33) 0%,rgb(233,64,87) 50%,rgb(138,35,135) 100%)',
    },
  },
  [`& .${stepConnectorClasses.line}`]: {
    height: 3,
    border: 0,
    backgroundColor:
      theme.palette.mode === 'dark' ? theme.palette.grey[800] : '#eaeaf0',
    borderRadius: 1,
  },
}));

const ColorlibStepIconRoot = styled('div')(({ theme, ownerState }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? theme.palette.grey[700] : '#ccc',
  zIndex: 1,
  color: '#fff',
  width: 50,
  height: 50,
  display: 'flex',
  borderRadius: '50%',
  justifyContent: 'center',
  alignItems: 'center',
  ...(ownerState.active && {
    backgroundImage:
      'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
    boxShadow: '0 4px 10px 0 rgba(0,0,0,.25)',
  }),
  ...(ownerState.completed && {
    backgroundImage:
      'linear-gradient( 136deg, rgb(242,113,33) 0%, rgb(233,64,87) 50%, rgb(138,35,135) 100%)',
  }),
}));

function ColorlibStepIcon(props) {
  const { active, completed, className } = props;

  const icons = {
    1: <SettingsIcon />,
    2: <OpenInFullIcon />,
    3: <VideoLabelIcon />,
  };

  return (
    <ColorlibStepIconRoot ownerState={{ completed, active }} className={className}>
      {icons[String(props.icon)]}
    </ColorlibStepIconRoot>
  );
}

ColorlibStepIcon.propTypes = {
  active: PropTypes.bool,
  className: PropTypes.string,
  completed: PropTypes.bool,
  icon: PropTypes.node,
};

export default function FullScreenDialog() {
  const [activeStep, setActiveStep] = React.useState(0);
  const email = localStorage.getItem('email');
  const [userData, setUserData] = useState(null);
  const [inputValue, setInputValue] = useState('');
  const [exitBtn, setExitBtn] = React.useState(false);

  useEffect(() => {
      axios
      .get(`http://localhost:3001/api/get/${email}`)
        .then((response) => {
          const userFromAPI = response.data[0];
          setUserData(userFromAPI);
        })
        .catch((error) => {
          console.error("Errore durante la richiesta API:", error);
        });
    }, []);

  const calculateRemainingChars = (maxChars, usedChars) => {
      return maxChars - usedChars;
  };

  if (!userData) {
      return <div>Caricamento...</div>;
  }

  const remainingCharsD = calculateRemainingChars(userData.CaratteriGiornalieri, userData.charD);
  const remainingCharsW = calculateRemainingChars(userData.CaratteriSettimanali, userData.charW);
  const remainingCharsM = calculateRemainingChars(userData.CaratteriMensili, userData.charM);

  const handleExitBtn = () => {
    setExitBtn(true);
  };

  if (exitBtn) {
    return (
      <div>
        <Home />
      </div>
    );
  }

  const steps = ['Caratteri Rimanenti', 'Quanti caratteri vuoi acquistare', 'Pagamento'];

  const QontoConnector = styled(StepConnector)(({ theme }) => ({
    [`&.${stepConnectorClasses.alternativeLabel}`]: {
      top: 10,
      left: 'calc(-50% + 16px)',
      right: 'calc(50% + 16px)',
    },
    [`&.${stepConnectorClasses.active}`]: {
      [`& .${stepConnectorClasses.line}`]: {
        borderColor: '#784af4',
      },
    },
    [`&.${stepConnectorClasses.completed}`]: {
      [`& .${stepConnectorClasses.line}`]: {
        borderColor: '#784af4',
      },
    },
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: theme.palette.mode === 'dark' ? theme.palette.grey[800] : '#eaeaf0',
      borderTopWidth: 3,
      borderRadius: 1,
    },
  }));

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };


  
  const handleClose  = () =>{
    handleAggiuntaCaratteriD();
    handleAggiuntaCaratteriW();
    handleAggiuntaCaratteriM();
    alert("Acquisto effettuato con successo");
    setActiveStep(0);
  };

  const handleAggiuntaCaratteriD = async () => {
    try {
      const response = await axios.post('http://localhost:3001/post/AggiuntaCaratteriD', {
        mail: email,
        newChar: inputValue 
      }); 
      // Richiedi nuovamente i dati aggiornati degli utenti
      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleAggiuntaCaratteriW = async () => {
    try {
      const response = await axios.post('http://localhost:3001/post/AggiuntaCaratteriW', {
        mail: email,
        newChar: inputValue 
      });

      // Richiedi nuovamente i dati aggiornati degli utenti
      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleAggiuntaCaratteriM = async () => {
    try {
      const response = await axios.post('http://localhost:3001/post/AggiuntaCaratteriM', {
        mail: email,
        newChar: inputValue 
      });
      // Richiedi nuovamente i dati aggiornati degli utenti
      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  return (

    <div>
      
      <div id="divCloseWindow" onClick={handleExitBtn}>
        <CloseIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', color: 'white' }}>

        <Stack sx={{ width: '100%' }} spacing={4}>

        <Stepper  alternativeLabel activeStep={activeStep} connector={<QontoConnector />}>
          {steps.map((label, index) => (
            <Step key={label}>
              <StepLabel StepIconComponent={QontoStepIcon} id="carrello-step-label">{label}</StepLabel>
            </Step>
          ))}
        </Stepper>

          <div id="carrello-riepilogo">

            {activeStep === 0 && (
              <Card>
                <CardContent sx={{  display: 'flex', flexDirection:"column",textAlign:"center", justifyContent: 'center', width:"500px", height:"200px"}}>
                  <Typography gutterBottom variant="h5" component="div">
                    Caratteri
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    <p>
                      <b> Caratteri Giornalieri: </b>
                      {remainingCharsD}{' '}
                    </p>
                    <p>
                      {' '}
                      <b> Caratteri Settimanali: </b>
                      {remainingCharsW}
                    </p>
                    <p>
                      <b> Caratteri Mensili: </b>
                      {remainingCharsM}
                    </p>
                  </Typography>
                </CardContent>
              </Card>
            )}

            {activeStep === 1 && (

              <Card>
                <CardActionArea>
                  <CardContent sx={{  display: 'flex', flexDirection:"column",textAlign:"center", justifyContent: 'center', width:"500px", height:"200px"}}>
                    <Typography gutterBottom variant="h5" component="div">
                     Quanti caratteri vuoi acquistare:
                    </Typography>
                    <FormControl sx={{ m: 1, display: 'flex', flexDirection: 'row', justifyContent: 'center' }} variant="outlined">
                      <OutlinedInput
                        sx={{marginRight: '10px'}}
                        id="outlined-adornment-weight"
                        aria-describedby="outlined-weight-helper-text"
                        value={inputValue}
                        onChange={handleInputChange}
                        inputProps={{
                          'aria-label': 'weight',
                        }}
                      />
                    </FormControl>
                  </CardContent>
                </CardActionArea>
              </Card>

            )}

            {activeStep === 2 && (
              <Card >
                <CardActionArea>
                  <CardContent sx={{  display: 'flex', flexDirection:"column",textAlign:"center", justifyContent: 'center', width:"500px", height:"200px"}}>
                    <Typography gutterBottom variant="h5" component="div">
                      Riepilogo:
                    </Typography>
                    <Alert severity="info" sx={{marginBottom: '10px'}}>
                      Stai acquistando {inputValue} caratteri.
                    </Alert>
                    <Button variant="contained" onClick={handleExitBtn}>
                      Paga
                    </Button>
                  </CardContent>
                </CardActionArea>
              </Card>

            )}
          </div>

          <div style={{ display: 'flex', justifyContent: 'center' }}>
          {activeStep !== 0 && (
            <IconButton disabled={activeStep === 0} onClick={handleBack}>
              <ArrowBackIosIcon style={{ color: 'white' }} />
            </IconButton>
            )}
            {activeStep !== 2 && (
            <IconButton disabled={activeStep === steps.length - 1} onClick={handleNext}>
              <ArrowForwardIosIcon style={{ color: 'white' }} />
            </IconButton>
             )}
          </div>
         
        </Stack>

      </div>
      
    </div>
  );
}