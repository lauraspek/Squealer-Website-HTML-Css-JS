import React, { useState } from 'react';
import Carrello1 from './AcquistaCaratteri'; // Assicurati di importare il componente Carrello1 correttamente

const TestModal = () => {
  const [modalVisible, setModalVisible] = useState(false);

  const handleApriModal = () => {
    setModalVisible(true);
  };

  const handleCloseModal = () => {
    setModalVisible(false);
  };

  return (
    <div>
      <h1>Benvenuto alla Pagina di Acquisto</h1>
      <button onClick={handleApriModal}>Apri Modal Acquisto</button>

      {modalVisible && (
        <Carrello1 onClose={handleCloseModal} />
      )}
    </div>
  );
};

export default TestModal; 
