import React, { useState } from 'react';

const ModalAcquisto = ({ onClose }) => {
  const [step, setStep] = useState(1);

  const handleNextStep = () => {
    setStep(step + 1);
  };

  const handlePreviousStep = () => {
    setStep(step - 1);
  };

  const handleAcquisto = () => {
    // Implementa la logica di acquisto qui
    // Dopo l'acquisto, puoi chiudere il modal
    onClose();
  };

  return (
    <div className="modal">
      <div className="modal-content">
        {step === 1 && (
          <div>
            <h2>Step 1: Seleziona i caratteri</h2>
            {/* Aggiungi qui il tuo codice per selezionare i caratteri */}
            <button onClick={handleNextStep}>Prossimo</button>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2>Step 2: Conferma l'acquisto</h2>
            {/* Aggiungi qui il riepilogo dell'acquisto e il pulsante di conferma */}
            <button onClick={handleNextStep}>Prossimo</button>
            <button onClick={handlePreviousStep}>Indietro</button>
          </div>
        )}

        {step === 3 && (
          <div>
            <h2>Step 3: Pagamento</h2>
            {/* Aggiungi qui il tuo modulo di pagamento */}
            <button onClick={handleAcquisto}>Conferma Acquisto</button>
            <button onClick={handlePreviousStep}>Indietro</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ModalAcquisto;
