import * as React from 'react';
import axios from 'axios';
import { useEffect } from 'react';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Typography from '@mui/material/Typography';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import StepConnector, { stepConnectorClasses } from '@mui/material/StepConnector';
import FormControl from '@mui/material/FormControl';
import { useState } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import OutlinedInput from '@mui/material/OutlinedInput';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import CardActionArea from '@mui/material/CardActionArea';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

const QontoConnector = styled(StepConnector)(({ }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 10,
    left: 'calc(-50% + 16px)',
    right: 'calc(50% + 16px)',
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: '#784af4',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: '#784af4',
    },
  },
}));



const AcquistaCaratteriVip = ({ handleClick }) => {

  const [activeStep, setActiveStep] = React.useState(0);
  const username = localStorage.getItem('email');
  const email = localStorage.getItem('email');
  const [userData, setUserData] = useState(null);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
      axios
      .get(`http://localhost:3001/api/get/${email}`)
        .then((response) => {
          const userFromAPI = response.data[0];
          setUserData(userFromAPI);
        })
        .catch((error) => {
          console.error("Errore durante la richiesta API:", error);
        });
    }, []);


  if (!userData) {
      return <div>Caricamento...</div>;
  }




  const steps = ['Caratteri rimanenti', 'Quanti caratteri vuoi acquistare', 'Pagamento'];

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };



  
  const handleClose  = () =>{
    handleAggiuntaCaratteri();
    alert("Acquisto effettuato con successo");
    setActiveStep(0);
    handleClick();
  };

  const handleAggiuntaCaratteri = async () => {
    try {
      const response = await axios.post('http://localhost:3001/post/AggiuntaChar', {    //Aggiungo i caratteri
        mail: username,
        newChar: inputValue
      });

    } catch (error) {
      console.error(error);
    }
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };


  return (
    <div id="vip_sub_pages">
      
      <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>

    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', color: 'white' }}>

      <Stack sx={{ width: '100%' }} spacing={4}>

      <Stepper  alternativeLabel activeStep={activeStep} connector={<QontoConnector />}>
        {steps.map((label, index) => (
          <Step key={label}>
            <StepLabel  id="carrello-step-label">{label}</StepLabel>
          </Step>
        ))}
      </Stepper>

        <div id="carrello-riepilogo">

          {activeStep === 0 && (
            <Card>
              <CardContent sx={{  display: 'flex', flexDirection:"column",textAlign:"center", justifyContent: 'center', width:"500px", height:"200px"}}>
                <Typography gutterBottom variant="h5" component="div">
                  Caratteri
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  <p>
                    <b> Caratteri Giornalieri: </b>
                    {userData.CaratteriGiornalieri}{' '}
                  </p>
                  <p>
                    {' '}
                    <b> Caratteri Settimanali: </b>
                    {userData.CaratteriSettimanali}
                  </p>
                  <p>
                    <b> Caratteri Mensili: </b>
                    {userData.CaratteriMensili}
                  </p>
                </Typography>
              </CardContent>
            </Card>
          )}

          {activeStep === 1 && (

            <Card>
              <CardActionArea>
                <CardContent sx={{  display: 'flex', flexDirection:"column",textAlign:"center", justifyContent: 'center', width:"500px", height:"200px"}}>
                  <Typography gutterBottom variant="h5" component="div">
                   Quanti caratteri vuoi acquistare:
                  </Typography>
                  <FormControl sx={{ m: 1, display: 'flex', flexDirection: 'row', justifyContent: 'center' }} variant="outlined">
                    <OutlinedInput
                      sx={{marginRight: '10px'}}
                      id="outlined-adornment-weight"
                      aria-describedby="outlined-weight-helper-text"
                      value={inputValue}
                      onChange={handleInputChange}
                      inputProps={{
                        'aria-label': 'weight',
                      }}
                    />
                  </FormControl>
                </CardContent>
              </CardActionArea>
            </Card>

          )}

          {activeStep === 2 && (
            <Card >
              <CardActionArea>
                <CardContent sx={{  display: 'flex', flexDirection:"column",textAlign:"center", justifyContent: 'center', width:"500px", height:"200px"}}>
                  <Typography sx={{marginBottom: '3vh', color:'black'}}>
                    Stai acquistando {inputValue} caratteri.
                  </Typography>
                  <Button style={{background: 'linear-gradient(to right, #000000, #5e071a)', color:'white', height:'5vh', borderRadius:'15px'}} variant="contained" onClick={handleClose}>
                    Paga
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>

          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'center' }}>
        {activeStep !== 0 && (
          <IconButton disabled={activeStep === 0} onClick={handleBack}>
            <ArrowBackIosIcon style={{ color: 'white' }} />
          </IconButton>
          )}
          {activeStep !== 2 && (
          <IconButton disabled={activeStep === steps.length - 1} onClick={handleNext}>
            <ArrowForwardIosIcon style={{ color: 'white' }} />
          </IconButton>
           )}
        </div>
       
      </Stack>

    </div>
    
  </div>
);
}
export default AcquistaCaratteriVip;