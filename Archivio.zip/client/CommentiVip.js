import React, { useEffect, useState } from "react";
import axios from "axios";
import { DataGrid } from "@mui/x-data-grid";

import "./style.css";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

const CommentiVip = ({ handleClick }) => {

  const [userData, setUserData] = React.useState([]);

  const username = localStorage.getItem('email');

  useEffect(() => {
    axios
    .get(`http://localhost:3001/api/commenti/${username}`)    //prendiamo tutti i commenti ricevuti sotto un post del vip
  
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);

  const getRowClassName = (params) => {
    return "white-row";
  };

  const getColumnHeaderClassName = (params) => {
    return "white-column-header";
  };




  const columns = [
    { field: "id", headerName: "Id", width: 170, headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.id}</div>
    ), },
    { field: "idMessaggio", headerName: "Id Messaggio", width: 170, headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.idMessaggio}</div>
    ),},
    { field: "Commentatore", headerName: "Commentatore", width: 170, headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.Commentatore}</div>
    ), },
    { field: "testo", headerName: "Testo", width: 300, headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.testo}</div>
    ),},
  ];

  const theme = createTheme({
    components: {
      MuiDataGrid: {
        styleOverrides: {
          columnHeader: {
            color: 'white',
          },
        },
      },
    },
  });

  return (
    <div id="vip_sub_pages">
      <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>
      <div id="DataGridUserPage">
          <ThemeProvider theme={theme}>
          <h2 style={{ color:'white', fontSize:'3vh',position:'relative', bottom:'6vh' }}>Commenti</h2>
            <DataGrid
              rows={userData}
              columns={columns}
              pageSize={5}
              getRowClassName={getRowClassName}
              getColumnHeaderClassName={getColumnHeaderClassName}
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.8)', 
                color: 'black', 
                position:'relative',
                bottom:'5vh'
              }}
            />
          </ThemeProvider>
        </div>

    </div>
  );
};
export default CommentiVip;
