import React, { useEffect, useState } from 'react'; 
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import Divider from '@mui/material/Divider';
import axios from 'axios';
import Box from '@mui/material/Box';
import { Button } from "@mui/material"; 
import './style.css'
import FirstPage from './PaginaIniziale';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { Card, CardContent, Typography } from '@mui/material';

const styles = {
  containerNoLogin: {
    display: 'flex',
    flexDirection: 'column', 
    alignItems: 'center', 
  },
  containerCanali: {
    backgroundColor: 'transparent',
    width: '100vw',
    height: '100vh',
    display: 'flex',
  },
  containerMessaggi: {
    backgroundColor: 'transparent',
    color: 'white',
    alignItems: 'center',
    flexDirection: 'column',   
    width: '100vw', 
    overflowY: 'auto',
    paddingLeft: '20px',
    display: 'flex',
  },
  messaggiTitle: {
    marginTop: '10px',
  },
  closeButton: {
    position: 'absolute',
    top: '50px',
    right: '50px',
    margin: '10px',
    backgroundColor: 'red',
    color: 'white',
  },
};

const computerStyles = {
  containerNoLogin: {
    display: 'flex',
    flexDirection: 'column', 
    alignItems: 'center', 
  },
  containerChannel: {
    display: 'flex',
    width: '24vw',
    backgroundColor: 'transparent' ,
    height: '100vh',

  },
  containerMessages: {
    width: '76vw', 
    overflowY: 'auto',
    alignItems: 'center',
    display: 'flex',
    flexDirection: 'column',
    paddingLeft: '20px',
    backgroundColor: 'transparent',
    color: 'white'
  },
  messaggiTitle: {
    marginTop: '10px',
  },
  closeButton: {
    position: 'absolute',
    top: '50px',
    right: '50px',
    margin: '10px',
    backgroundColor: 'red',
    color: 'white',
  },
};

const ProvaGratuita = () => {
  const [channelSquealer, setChannelSquealer] = useState([]);
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [channelMessages, setChannelMessages] = useState([]);
  const [channelList, setChannelList] = useState(true);
  const [channel, setChannel] = useState(false);
  const [goBack, setGoBack] = React.useState(false);
  const [MobileMode, setMobileMode] = useState(window.innerWidth <= 768); 

  useEffect(() => {
    axios
      .get("http://localhost:3001/get/canaliSquealer")
      .then((response) => {
        setChannelSquealer(response.data);
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  }, []);

  useEffect(() => {
    if (selectedChannel) {
      axios
        .get(`http://localhost:3001/get/messaggiDelCanale/${selectedChannel}`)
        .then((response) => {
          setChannelMessages(response.data);
        })
        .catch((error) => {
          console.error("Error:", error);
        });
    }
  }, [selectedChannel]);


  useEffect(() => {
    const handleResize = () => {
      setMobileMode(window.innerWidth <= 768); 
    };
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);


  const handleSelectedChannel = (nameChannel) => {
    setSelectedChannel(nameChannel);
    if(MobileMode){
      setChannel(true);
      setChannelList(false);  
    } else {
      setChannel(true);
      setChannelList(true);  
    }
  };

  const goToLogIn = () => { 
    setGoBack(true); 
}; 



  if (goBack) {
    return (
      <div>
        <FirstPage />
      </div>
    );
  }

  const openLista = () => {
    if(MobileMode){
      setChannel(false);
      setChannelList(true);  
    } else {
      setChannel(true);
      setChannelList(true);  
    }
  };



  return (
    <div> 
       <Box sx={{ position: 'absolute', top: '5vh', left: '10vh', margin: '10px' }}> 
     <Button   
     variant='contained' 
     color='secondary' 
     onClick={goToLogIn}  
     style={{background: 'linear-gradient(to right, #000000, #5e071a)', color:'white', height:'7vh', marginTop:'2vh',fontWeight: 'bold' }} >Torna indietro</Button> 
 </Box> 

      <div style={styles.containerNoLogin}>    

        {channelList && MobileMode &&
          <div id="containerCanali" style={styles.containerChannel}>
            <List
              id="listItem"
              sx={{maxWidth: '100%',bgcolor: 'background.paper',}}
            >

              {channelSquealer.map((channel, index) => (
                <React.Fragment key={channel.nome}>
                  <ListItem button onClick={() => handleSelectedChannel(channel.nome)}>
                    <ListItemAvatar>
                      <Avatar>{index + 1}</Avatar>
                    </ListItemAvatar>
                    <ListItemText primary={channel.nome} secondary={channel.dataCreazione} />
                  </ListItem>
                  {index < channelSquealer.length - 1 && <Divider variant="inset" component="li" />}
                </React.Fragment>
              ))}
            </List></div>
        }

        {channel && MobileMode &&(

            <div style={styles.containerMessages}>

              <div style={{position: "absolute", left: "30px",top: "120px"}}>
                <ArrowBackIosIcon onClick={openLista} style={{  cursor: 'pointer',color: 'white' }} />
              </div>

              <h2 style={styles.messaggiTitle}>Un piccolo assaggio...</h2>

              <div style={{ justifyContent:"center", display:"flex" ,width:"50vw"}}>
              {channelMessages.map((messages) => (
              <Card key={messages.id} style={{ maxWidth: '400px' ,margin: '10px' }}>
                <CardContent>
                <Typography component="div" variant="h6" >
                    {messages.mittente}
                  </Typography>
                  <Typography component="div" variant="h6" >
                    {messages.testo}
                  </Typography>
                  <Typography color="textSecondary">
                    {messages.data}
                  </Typography>
                  {/* Add more fields as needed */}
                </CardContent>
              </Card>
            ))}
            </div></div>

        )}


        {!MobileMode &&

        <div style={{width:'100%'}}>

<div id="containerCanaliNotMobile" style={{ overflowX: 'auto', }}>
            <List
              id="listItem"
              sx={{
                display: 'flex', 
                flexDirection: 'row', 
                width: '100%',
                bgcolor: 'white',
                height:'10vh', boxShadow: '0px -5px 10px 0px black',
               position:'absolute', 
               bottom:'0'
              }}
            >

              {channelSquealer.map((channel, index) => (
                <React.Fragment key={channel.nome}>
                  <ListItem button style={{color:'#5e071a',borderRight: '2px solid #5e071a',}} onClick={() => handleSelectedChannel(channel.nome)}>
                    <ListItemAvatar>
                      <Avatar style={{background:'#5e071a', color:'white', borderRadius:'10px'}}>{index + 1}</Avatar>
                    </ListItemAvatar>
                    <ListItemText primary={channel.nome} secondary={channel.dataCreazione} />
                  </ListItem>
                  {index < channelSquealer.length - 1 && <Divider variant="inset" component="li" />}
                </React.Fragment>
              ))}
            </List></div>

          <div id="containerMessaggi">

              <h2  id="titleMessage" >Un piccolo assaggio...</h2>
            
              {channelMessages.map((messages) => (
  <Card key={messages.id} style={{ margin: '10px', background: 'white', width: '100%', height: '10vh', display: 'flex',  boxShadow: '4px 0 8px rgba(94, 7, 26, 0.9), -4px 0 8px rgba(94, 7, 26, 0.9)', }}>
    <CardContent style={{ display: 'flex', width: '100%'}}>
      <Typography variant="h6" component="div" style={{ flex: '1', padding: '5px' }}>
        {messages.mittente}
      </Typography>
      <Typography variant="h6" component="div" style={{ flex: '1', padding: '5px' }}>
        {messages.testo}
      </Typography>
      <Typography color="textSecondary" style={{ flex: '1',  padding: '5px' }}>
        {messages.data}
      </Typography></CardContent></Card>
))}
 </div></div>}
</div></div>
  );
};

export default ProvaGratuita;
