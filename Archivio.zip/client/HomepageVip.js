import React, { useState } from "react";
import {Divider} from "@mui/material";
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import InfoRoundedIcon from '@mui/icons-material/InfoRounded';
import CommentIcon from '@mui/icons-material/Comment';
import { SlLoop } from "react-icons/sl";
import ImpostazioniVip from "./ProfiloVip";
import VisualizzaCommentiVip from "./CommentiVip";
import VisualizzaPopolaritaVip from "./PopolaritaVip";
import AcquistaCaratteri from './AcquistaCaratteri'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import InsightsIcon from '@mui/icons-material/Insights';
import { BottomNavigation, BottomNavigationAction, Button } from "@mui/material"; 
import Posts from "../components/allposts/AllPosts"
import Share from "../components/mypost/MyPost"
import NewsFeed from '../components/newsRss/News';
import MessaggiTemporizzati from '../components/messTemp/MessaggiTemporizzati'
import LogoutIcon from '@mui/icons-material/Logout';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import Segui from "../client/IscrizioneCanale";

const HomepageVip = () => {

    const [modal, setModal] = useState(false);
    const [modalBuyCharacter, setBuyCharacte] = useState(false);
    const [modalViewComment, setViewComment] = useState(false);
    const [modalStatistiche, setStatistiche] = useState(false);
    const [modalPerson, setPersonVisible] = useState(false);
    const [follow,setFollow] = useState(false); 
    const [mobileOpen, setMobileOpen] = useState(false);
    

    if(localStorage.getItem('reloadPage')){
        localStorage.setItem('reloadPage',false);
      }

    

    const handleToggleModal = (modalId) => {
        switch (modalId) {
          case 'Follow':
            setFollow(!follow);
            setStatistiche(false);
            setPersonVisible(false);
            setViewComment(false);
            break;
          case 'BuyCharacter':
            setBuyCharacte(!modalBuyCharacter);
            setStatistiche(false);
            setPersonVisible(false);
            setViewComment(false);
            break;
            case 'Statistiche':
                setStatistiche(!modalStatistiche);
                setPersonVisible(false);
                setViewComment(false);
                setBuyCharacte(false);
              break;
              case 'infoPerson':
                setPersonVisible(!modalPerson);
                setViewComment(false);
                setBuyCharacte(false);
                setStatistiche(false);
              break;
              case 'ViewComment':
                setViewComment(!modalViewComment);
                setBuyCharacte(false);
                setStatistiche(false);
                setPersonVisible(false);
              break;
              case 'Home':
                setViewComment(false);
                setBuyCharacte(false);
                setStatistiche(false);
                setPersonVisible(false);
              break;
            default:
            break;
        }
      };

    const handleRefresh = () => { 
        localStorage.setItem('reloadPage',true);
        window.location.reload();

    };

    const handleLogOut = () => {
        localStorage.setItem('reloadPage',false);
        localStorage.setItem('email',"");
        localStorage.setItem('password',"");
        localStorage.setItem('userType',"");
        localStorage.setItem('name',"");
        localStorage.setItem('surname',"");
        window.location.reload();
    };





    return (
        <div id="altezza">
             
             <div id="logoApp"></div> 
                <p><h2 id="titleModerator">SQUEALER</h2></p> 

<div className="home" id="pageVip">

      <MessaggiTemporizzati/>
      <Share/>
      <Posts/>
      <NewsFeed/>


    </div>

   
    <Divider /> 


        <BottomNavigation 
        value={0} 
        onChange={(event, newValue) => { 
        // Gestione cambio di pagina 
        switch (newValue) { 
        case 0: 
            handleToggleModal('Follow'); 
            break; 
        case 1: 
            handleToggleModal('BuyCharacter'); 
            break; 
        case 2: 
            handleToggleModal('ViewComment'); 
            break; 
        case 3: 
            handleToggleModal('Statistiche'); 
            break; 
        case 4: 
            handleToggleModal('infoPerson'); 
            break; 
        case 5: 
            handleLogOut();
        break;
          default:
            break;
        } 
        }} 
        showLabels 
        sx={{ position: 'fixed', bottom: 0, width: '100%', bgcolor: '#5e071a', color: 'white',  height: '11vh', 
        '& .Mui-selected': { 
        color: 'white',  
        }, 
        '& .MuiBottomNavigationAction-label': { 
        color: 'white',  
        }, 
        }} 
    > 
            <BottomNavigationAction label="Segui Canali" icon={<BookmarkIcon style={{ color: 'white' }} />} /> 
            <BottomNavigationAction label="Acquista Caratteri" icon={<ShoppingCartIcon style={{ color: 'white' }}/>} /> 
            <BottomNavigationAction label="Visualizza Commenti" icon={<CommentIcon style={{ color: 'white' }}/>} /> 
            <BottomNavigationAction label="Statistiche" icon={<InsightsIcon style={{ color: 'white' }}/>} /> 
            <BottomNavigationAction label="Profilo" icon={<InfoRoundedIcon style={{ color: 'white' }}/>} /> 
            <BottomNavigationAction label="Logout" icon={<LogoutIcon style={{ color: 'white' }} />} onClick={handleLogOut}/>
            <BottomNavigationAction style={{ position:'relative', right:'2vh'}} label="Refresh" icon={<SlLoop  style={{ color: 'white', width:'2.6vh', height:'2.6vh'  }} />} onClick={handleRefresh}/>

            </BottomNavigation> 

            {modalBuyCharacter && (
                <div className="modal">
                    <AcquistaCaratteri  handleClick={() => handleToggleModal('BuyCharacter')}></AcquistaCaratteri>
                </div>
                )}

              {follow && (
                <div className="modal">
                    <Segui  handleClick={() => handleToggleModal('Follow')}></Segui>
                </div>
                )}  

                {modalViewComment && (
                <div className="modal">
                    <VisualizzaCommentiVip  handleClick={() => handleToggleModal('ViewComment')}></VisualizzaCommentiVip>
                </div>
                )}
                {modalStatistiche && (
                <div className="modal">
                    <VisualizzaPopolaritaVip  handleClick={() => handleToggleModal('Statistiche')}></VisualizzaPopolaritaVip >
                </div>
                )}
                {modalPerson && (
                <div className="modal">
                    <ImpostazioniVip  handleClick={() => handleToggleModal('infoPerson')}></ImpostazioniVip>
                </div>
                )}

        </div>
    );
};

export default HomepageVip;