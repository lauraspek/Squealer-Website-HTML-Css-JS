import React from 'react'; // Importa useState e useEffect da 'react'
import NavBar from "../components/navbar/Navbar";
import NewsFeed from '../components/newsRss/News';
import Posts from "../components/allposts/AllPosts";
import Share from "../components/mypost/MyPost";
import MessaggiTemporizzati from '../components/messTemp/MessaggiTemporizzati';
import "./home.scss";

const Homepage = () => {

  if(localStorage.getItem('reloadPage')){
    localStorage.setItem('reloadPage',false);
  }

  return (
    <div className="home">
      <NavBar/>     
      <Share/>
      <Posts/>
      <NewsFeed/>
      <MessaggiTemporizzati/>
    </div>
  );
}

export default Homepage;
