import React, { useEffect, useState } from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import "./style.css";
import axios from "axios";
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { DataGrid } from '@mui/x-data-grid';
import { TextField, Stack} from "@mui/material";
import Button from "@mui/material/Button";


const GestioneCanaliMod= ({ handleClick }) => {
  const [newChannelName, setNewChannelName] = useState("");
  const [selectedRow, setSelectedRow] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [newOwner, setNewProprietario] = useState("");
  const [userData, setUserData] = useState([]);
  const [openOwnerDialog, setOpenOwnerDialog] = useState(false);
  const [openRenameDialog, setOpenRenameDialog] = useState(false);

  useEffect(() => {
    axios
      .get("http://localhost:3001/get/canaliMinSquealer")
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);


  const handleRowDoubleClick = (params) => {
    setSelectedRow(params.row);
    setOpenDialog(true);
  };

  const getRowId = (channel) => channel.nome;

  const getColumnHeaderClassName = (params) => {
    return "white-column-header";
  };

 
  const getRowClassName = (params) => {
    return "white-row";
  };


  const handleUnblockChannel = async (nome) => {
    try {
        const response = await axios.put(`http://localhost:3001/canali/${nome}/stato`, { stato: 'sbloccato' });
        const updatedResponse = await axios.get("http://localhost:3001/get/canaliMinSquealer");
        setUserData(updatedResponse.data);
    } catch (error) {
        console.error(error);
    }
  };

  const handleBlockChannel = async (nome) => {
    try {
        const response = await axios.put(`http://localhost:3001/canali/${nome}/stato`, { stato: 'bloccato'});
        const updatedResponse = await axios.get("http://localhost:3001/get/canaliMinSquealer");
        setUserData(updatedResponse.data);
    } catch (error) {
        console.error(error);
    }
  };

  const handleRenameChannel = async () => {
    try {
      if (!selectedRow || !newChannelName) {
        return;
      }
      await axios.put(
        `http://localhost:3001/canali/${selectedRow.nome}/nome`,
        {
          nuovoNome: newChannelName,
        }
      );

      setOpenRenameDialog(false);
      setNewChannelName(""); 
      const updatedResponse = await axios.get("http://localhost:3001/get/canaliMinSquealer");
      setUserData(updatedResponse.data);
      setOpenDialog(false);
    } catch (error) {
      console.error(error);
    }
  };

  const handleOwnerChange = async () => {
    try {
      if (!selectedRow || !newOwner) {
        return;
      }
      await axios.put(
        `http://localhost:3001/canali/${selectedRow.nome}/proprietario`,
        {
          nuovoProprietario: newOwner,
        }
      );
  
      setOpenOwnerDialog(false);
      setNewProprietario(""); 
  
      const updatedResponse = await axios.get("http://localhost:3001/get/canaliMinSquealer");
      setUserData(updatedResponse.data);
      setOpenDialog(false);
    } catch (error) {
      console.error(error);
    }
  };
  

  const columns = [
    {
      width: 200,
      headerName: "Nome Canale",
      field: "nome",
      headerClassName: 'custom-header', 
      renderCell: (params) => (
        <div style={{ color: 'black' }}>{params.row.nome}</div>
      ),
    },
    {
      headerClassName: 'custom-header',
      headerName: "Descrizione",
      field: "descrizione",
      width: 300,
     renderCell: (params) => (
        <div style={{ color: 'black' }}>{params.row.descrizione}</div>
      ),
    },
    {
      headerClassName: 'custom-header', 
      headerName: "Proprietario",
      width: 150,
      field: "proprietarioEmail",
      renderCell: (params) => (
        <div style={{ color: 'black' }}>{params.row.proprietarioEmail}</div>
      ),
    },
    {
      width: 100,
      headerName: "Blocca",
      headerClassName: 'custom-header', 
      field: "blocca",
      renderCell: (params) => {
        if (params.row.stato === 'sbloccato') {
          return (
            <Button
            style={{ width: '15vh', background: 'linear-gradient(to right, #000000, #5e071a)',  height: '5vh', borderRadius: '10px', alignSelf: 'center' }}
            color="secondary"
            onClick={() => handleBlockChannel(params.row.nome)}
              variant="contained"
            >
              Blocca
            </Button>
          );
        } else {
          return null;
        }
      },
    },
    {
      headerClassName: 'custom-header', 
      headerName: "Sblocca",
      width: 100,
      field: "Sblocca",

      renderCell: (params) => {
        if (params.row.stato === 'bloccato') {
          return (
            <Button
            onClick={() => handleUnblockChannel(params.row.nome)}
            color="secondary"
              variant="contained"
              style={{  borderRadius: '10px', width: '15vh',background: 'linear-gradient(to right, #000000, #5e071a)',  height: '5vh',alignSelf: 'center' }}
            >
              Sblocca
            </Button>
          );
        } else {
          return null;
        }
      },
    },
    {
      headerClassName: 'custom-header',
      width: 100,
      headerName: "Mod",
      field: "Mod",

      renderCell: (params) => (
        <Button
        onClick={() => handleRowDoubleClick(params)}
          color="secondary"
          style={{height:'5vh', background: 'linear-gradient(to right, #000000, #5e071a)', width:'15vh',borderRadius:'10px' ,  alignSelf:'center'}}
          variant="contained"
        >
          Apri
        </Button>
      ),
    },
  ];

  const theme = createTheme({
    components: {
      MuiDataGrid: {
        styleOverrides: {
          columnHeader: {
            color: "white",
          },
        },
      },
    },
  });

  return (
    <div id="mod_sub_pages_UsersPage">
            <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>
      <div id="DataGridUserPage">
        <ThemeProvider theme={theme}>
          <DataGrid
            getColumnHeaderClassName={getColumnHeaderClassName}
            ageSize={5}
            columns={columns}
            rows={userData}
            getRowClassName={getRowClassName}
            getRowId={getRowId}
            style={{
              color: 'black', 
              backgroundColor: 'rgba(255, 255, 255, 0.8)', 
            }}
            
          />
        </ThemeProvider>
      </div>
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle style={{ color: 'white', fontStyle:'italic', background: 'linear-gradient(to right, #000000, #5e071a)' }}>Dettagli Canale Pubblico</DialogTitle>
        <DialogContent style={{marginTop:'2vh'}}>
          {selectedRow && (
            <div style={{textAlign:"justify"}}>
              <p><strong>Nome canale:</strong> {selectedRow.nome}</p>
              <p><strong>Proprietario:</strong> {selectedRow.proprietarioEmail}</p>
              <p><strong>Descrizione:</strong> {selectedRow.descrizione}</p>

              <Stack direction="column" spacing={2}>
                <Button
                  variant="contained"
                  style={{borderRadius:'10px', marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', height:'5vh' }}
                  color="secondary"
                  onClick={() => setOpenRenameDialog(true)}
                >
                  Cambia nome canale
                </Button>
                <Button
                  variant="contained"
                  onClick={() => setOpenOwnerDialog(true)}
                  style={{ borderRadius:'10px',background: 'linear-gradient(to right, #000000, #5e071a)', height:'5vh' }}
                  color="secondary"
                >
                  Cambia proprietario 
                </Button>
                <Button onClick={() => setOpenDialog(false)} style={{  height:'5vh', background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', borderRadius:'10px' , width:'15vh', alignSelf:'center'}} color="secondary" >
            Annulla
          </Button>
              </Stack>
            </div>
          )}
        </DialogContent>
      </Dialog>


      <Dialog
        open={openRenameDialog}
        onClose={() => setOpenRenameDialog(false)}
      >
        <DialogTitle style={{ color: 'white',background: 'linear-gradient(to right, #000000, #5e071a)',  fontStyle:'italic' }}>Cambia Nome Canale</DialogTitle>
        <DialogContent style={{marginTop:'2vh'}}>
          <p> Cambia il nome di {selectedRow?.nome}: </p>
          <TextField
            onChange={(e) => setNewChannelName(e.target.value)}
            variant="outlined"
            value={newChannelName}
            style={{marginTop:'1vh'}}
            label="Nuovo Nome Canale"
            fullWidth
          />
        </DialogContent>
        <DialogActions style={{ justifyContent: 'center' }}>
        <Stack   alignItems="center" spacing={1} direction="row">
          <Button style={{ height:'5vh',color: 'white',  borderRadius:'10px' , background: 'linear-gradient(to right, #000000, #5e071a)', alignSelf:'center', width:'15vh'}} onClick={handleRenameChannel}  variant="contained" color="secondary">
            Salva
          </Button>
          <Button color="secondary"  style={{ height:'5vh', background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white',width:'15vh', alignSelf:'center', borderRadius:'10px' , }}variant="contained"  onClick={() => setOpenRenameDialog(false)}  >
            Annulla
          </Button>
        </Stack>
        </DialogActions>
      </Dialog>

      <Dialog open={openOwnerDialog} onClose={() => setOpenOwnerDialog(false)}>
        <DialogTitle style={{  color: 'white', fontStyle:'italic', background: 'linear-gradient(to right, #000000, #5e071a)'}}>Cambia Proprietario Canale</DialogTitle>
        <DialogContent style={{marginTop:'2vh'}}>
          <p>Cambia il proprietario di {selectedRow?.nome}: </p>
          <TextField
            label="Nuovo Proprietario Canale"
            variant="outlined"
            style={{marginTop:'1vh'}}
            value={newOwner}
            fullWidth
            onChange={(e) => setNewProprietario(e.target.value)}

          />
        </DialogContent>
        <DialogActions style={{ justifyContent: 'center' }}>
          <Button style={{borderRadius:'10px' , background: 'linear-gradient(to right, #000000, #5e071a)', height:'5vh', alignSelf:'center', width:'15vh',  color: 'white',}} onClick={handleOwnerChange}  variant="contained" color="secondary">
            Salva
          </Button>
          <Button onClick={() => setOpenOwnerDialog(false)} style={{ borderRadius:'10px', background: 'linear-gradient(to right, #000000, #5e071a)', height:'5vh' }}  color="secondary" variant="contained" >
            Annulla
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

export default GestioneCanaliMod;
