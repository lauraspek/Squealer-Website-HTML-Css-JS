import { useEffect } from "react";
import axios from "axios";
import "./style.css";
import React, { useState } from 'react';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { PieChart } from '@mui/x-charts/PieChart';


const PopolaritaVip = ({ handleClick }) => {
  
    const [positiveCount, setPositiveCount] = useState();
    const [negativeCount, setNegativeCount] = useState();
    const email =  localStorage.getItem('email');
    

  useEffect(() => {
    
    axios.get(`http://localhost:3001/get/like/${email}`)      //prendo tutti i like del vip
      .then((response) => {
        setPositiveCount(response.data.conteggio);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);


  useEffect(() => {
   
    axios.get(`http://localhost:3001/get/dislike/${email}`)       //prendo tutti i dislike del vip
      .then((response) => {
        setNegativeCount(response.data.conteggio);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);




    return(
      <div id="vip_sub_pages">

      <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon  size={20} />
      </div>

      <h2 id="titoloGraficoVip">Grafico dei giudizi</h2>

        <div id="grafico_squeal_vip">
        <PieChart 
    series={[
      {
        data: [
          { id: 0, value: positiveCount, label: 'Giudizi Positivi', color: 'red' },
          { id: 1, value: negativeCount, label: 'Giudizi Negativi', color: 'white' },
        ],
      },
    ]}
    sx={{ color: 'white' }}
    width={700}
    height={400}
  />
        </div>
      </div>
    );
}
export default PopolaritaVip;