import React from "react";
import Login from "./Login";
import FreeTrial from "./ProvaGratuita";
import './style.css';

const PaginaIniziale = () => {


    const [GetLogin, setLogin] = React.useState(false);
    const [FreeTrialState, setFreeTrial] = React.useState(false);

    if (localStorage.getItem('reloadPage') === 'true') {
        return (
            <div>
                <Login/>
            </div>
        );
    }
    

    if (GetLogin) {
        return (
          <div>
            <Login/>
          </div>
        );
    }

    if(FreeTrialState){
        return(
            <div>
                <FreeTrial/>
            </div>
        )
    }


    function goToLoginPage(){
        setLogin(true);
    }

    function goToFreeTrialPage(){
        setFreeTrial(true);
    }




    return (
       
        <div id="first-page-container">
             <div id="decoration"></div>
            <header id="headerFP">
                <h2>SQUEALER</h2>
                <h4>Invia messaggi a tutti, leggi le notizie attuali e molto altro ancora..</h4>
                    <button id="btnGetStarted" onClick={goToLoginPage}>INIZIA</button>
                    <p id="freeTrialLink">Vuoi continuare senza account?    <a id="linkFP" onClick={goToFreeTrialPage}>Clicca qui</a></p>
                
            </header>
            <main id="main">


            </main>
        </div>    
    )
};

export default PaginaIniziale;