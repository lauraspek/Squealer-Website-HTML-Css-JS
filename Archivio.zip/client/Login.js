import React from 'react';
import axios from 'axios';
import './style.css';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import Moderator from './HomepageMod';
import { useState } from 'react';
import FirstPage from './PaginaIniziale';
import Home from './Homepage';
import { Button } from '@mui/material';
import SignUp from './Signup';
import Vip from './HomepageVip';


const Login = () => {
  const [username, setUsername] = React.useState('');
  const [nome, setNome] = React.useState('');
  const [cognome, setCognome] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [goBack, setGoBack] = React.useState(false);
  const [signUp, setSignUp] = React.useState(false);
  const [userType, setUserType] = React.useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(true); // Nuova variabile di stato per il login

  React.useEffect(() => {
    const savedSurename = localStorage.getItem('surename');
    const savedEmail = localStorage.getItem('email');
    const savedType = localStorage.getItem('userType');
    const savedName = localStorage.getItem('name');
    const savedPassword = localStorage.getItem('password');
    if (savedSurename) {
      setCognome(savedSurename);
    }

    if (savedPassword) {
      setPassword(savedPassword);
    }

    if (savedName) {
      setNome(savedName);
    }
    if (savedType) {
      setUserType(savedType);
    }
    if (savedEmail) {
      setUsername(savedEmail);
    }
  }, []);



  React.useEffect(() => {
    localStorage.setItem('userType', userType);
  }, [userType]);

  React.useEffect(() => {
    localStorage.setItem('surename', cognome);
  }, [cognome]);
  
  React.useEffect(() => {
    localStorage.setItem('password', password);
  }, [password]);

  React.useEffect(() => {
    localStorage.setItem('name', nome);
  }, [nome]);

  React.useEffect(() => {
    localStorage.setItem('username', username);
  }, [username]);


  function handleGoBack() {
    setGoBack(true);
  }

  function showSignUP() {
    setSignUp(true);
  }

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.get('http://localhost:3001/api/get');
      const userList = response.data;

      const user = userList.find(
        (utente) => utente.email === username && utente.PasswordUtente === password
      );

      if (user) {
        setCognome(user.cognome);
        setNome(user.nome);
        let currentUserType = 'user';

        const responseMod = await axios.get('http://localhost:3001/api/getModeratore');
        const modList = responseMod.data;
  
        const responseVip = await axios.get('http://localhost:3001/api/getVip');
        const vipList = responseVip.data;
  
        if (modList.some((Moderatore) => Moderatore.ModeratoreEmail === username)) {
          currentUserType = 'moderator';
        } else if (vipList.some((UtenteVip) => UtenteVip.emailVip === username)) {
          currentUserType = 'vip';
        }
  
        setUserType(currentUserType);

        localStorage.setItem('email', username);
        localStorage.setItem('password', password);
        localStorage.setItem('userType', currentUserType);
        localStorage.setItem('name', user.nome);
        localStorage.setItem('surname', cognome);


        if (user.stato === 'bloccato') {
          localStorage.setItem('email', '');
          localStorage.setItem('password', '');
          localStorage.setItem('userType', '');
          localStorage.setItem('name', '');
          localStorage.setItem('surname', '');
          setIsLoggedIn(false); 
          alert(`L'utente ${username} è stato bloccato`);
        } else {
          setIsLoggedIn(true);
        }
      } else {
        alert('Invalid credentials');
        console.log(user);
        console.log(userList);
      }
    } catch (error) {
      console.error(error);
    }
  };





  if (localStorage.getItem('reloadPage') && userType === 'vip' && isLoggedIn) {
    return (
      <div>
        <Vip />
      </div>
    );
  }

  if (goBack) {
    return (
      <div>
        <FirstPage />
      </div>
    );
  }


 
  if (localStorage.getItem('reloadPage') && userType === 'user' && isLoggedIn) {
    return (
      <div>
        <Home />
      </div>
    );
  }

  if (localStorage.getItem('reloadPage') && userType === 'moderator') {
    return (
      <div>
        <Moderator />
      </div>
    );
  }

  if (signUp) {
    return (
      <div>
        <SignUp />
      </div>
    );
  }

  return (
    <div id="container">

         <div className="form-container" >
{}

      <h2 id="titleLogin">LOGIN</h2>

        <form onSubmit={handleLogin}>
        <div id="btn-form-exit" onClick={handleGoBack}><HighlightOffIcon size={20} sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} /></div>

          <input
            onChange={(e) => setUsername(e.target.value)}
            type="text"
            value={username}
            id="username"
            className="input-field"
            placeholder="Username"
            name="username"
          />

          <input
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            className="input-field"
            id="password"
            value={password}
            placeholder="Password"
            name="password"
          />

          <div id="form-btn-container">
            <Button
              type="submit"
              className="btnLogIn"
              id="btnLogIn"
            >
              Login
            </Button>
            <p id="registrationAc">
              Non possiedi un account? <a onClick={showSignUP}>Registrati</a>
            </p>

          </div>
        </form></div></div>
  );
};

export default Login;