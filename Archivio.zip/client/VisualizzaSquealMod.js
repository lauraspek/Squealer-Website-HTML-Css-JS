import DialogTitle from "@mui/material/DialogTitle";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import { TextField, Stack} from "@mui/material";
import "./style.css";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Button from "@mui/material/Button";
import DialogActions from "@mui/material/DialogActions";
import axios from "axios";
import React, { useEffect } from "react";
import { MenuItem } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";



const ReazioniDialog = ({ open, onClose, reazioni, onNuoveReazioni, onCambiaReazioni }) => {
  const possibility = [
    {
      label: 'positivo',
      value: 'positivo',
    },
    {
      label: 'negativo',
      value: 'negativo',
    },
  ];

  return (
    <Dialog onClose={onClose} open={open} >
      <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Cambia Giudizio</DialogTitle>
      <DialogContent style={{marginTop:'2vh'}}>
        <TextField
          select
          id="outlined-select-currency"
          label="Seleziona giudizio"
          onChange={onNuoveReazioni}
          style={{ width: '100%' }}
          value={reazioni}

        >
          {possibility.map((option) => (
            <MenuItem value={option.value} key={option.value} >
              {option.label}
            </MenuItem>
          ))}
        </TextField>
      </DialogContent>
      <DialogActions style={{ justifyContent: 'center' }}>
        <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}} onClick={onCambiaReazioni} variant="contained" color="secondary">
          Salva
        </Button>
        <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}} onClick={onClose} variant="contained" color="secondary">
          Annulla
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const VisualizzaSquealMod= ({ handleClick }) => {

  const [openDialog, setOpenDialog] = React.useState(false);
  const [selectedRow, setSelectedRow] = React.useState(null);
  const [nuovoDestinatario, setNuovoDestinatario] = React.useState("");
  const [reazioni, setReazioni] = React.useState("");
  const [selectedRowR, setSelectedRowR] = React.useState(null);
  const [openChangeDestinatarioDialog, setOpenChangeDestinatarioDialog] = React.useState(false);

  const [appreciationData, setAppreciationData] = React.useState([]);
  const [openDialogPop, setOpenDialogPop] = React.useState(false);
  const [userData, setUserData] = React.useState([]);

  const [isDiv1Visible, setDiv1Visible] = React.useState(false);
  const [isDiv2Visible, setDiv2Visible] = React.useState(false);

  const showDiv1 = () => {
    setDiv1Visible(true);
    setDiv2Visible(false); 
  };

  const showDiv2 = () => {
    setDiv1Visible(false);
    setDiv2Visible(true);
  };
  useEffect(() => {
    axios
      .get("http://localhost:3001/get/squealer")
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });

    axios
      .get("http://localhost:3001/get/apprezzamento")
      .then((response) => {
        setAppreciationData(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);

  const handleRowDoubleClick = (params) => {
    setSelectedRow(params.row);
    setOpenDialog(true);
  };

  const getColumnHeaderClassName = (params) => {
    return "white-column-header";
  };

  const getRowClassName = (params) => {
    return "white-row";
  };

  function handleOpenChangeDestinatarioDialog() {
    setOpenChangeDestinatarioDialog(true);
  }

  const handleRowDoubleClickReazioni = (params) => {
    setSelectedRowR(params.row);
    setOpenDialogPop(true);
  };



  const handleSalvaDestinatario = () => {
    axios
      .put(`http://localhost:3001/api/modifica-destinatario/${selectedRow.id}`, {
        nuovoDestinatario: nuovoDestinatario,
      })
      .then((response) => {
        if (response.data) {
          setOpenChangeDestinatarioDialog(false);

          setSelectedRow((prevSelectedRow) => ({
            ...prevSelectedRow,
            destinatario: nuovoDestinatario,
          }));

          setUserData((prevUserData) => {
            const updatedUserData = prevUserData.map((row) => {
              if (row.id === selectedRow.id) {
                return {
                  ...row,
                  destinatario: nuovoDestinatario,
                };
              }
              return row;
            });
            return updatedUserData;
          });
        } else {
          console.error("Errore nella modifica del destinatario");
        }
      })
      .catch((error) => {
        console.error("Errore nella richiesta API:", error);
      });
  };

  const handleChangeReaction = () => {
    axios
      .put(`http://localhost:3001/api/modifica-giudizio/${selectedRowR.idMessaggio}`, { giudizio: reazioni })
      .then((response) => {
        if (response.status === 200) {

          setAppreciationData((prevUserData) => {
            const updatedUserDataR = prevUserData.map((row) => {
              if (row.idMessaggio === selectedRowR.idMessaggio) {
                return {
                  ...row,
                  giudizio: reazioni,
                };
              }
              return row;
            });
            return updatedUserDataR;
          });
          setOpenDialogPop(false);
        }
      })
      .catch((error) => {
        if (error.response && error.response.status === 404) {
          console.log('Messaggio non trovato');
        } else {
          console.log('Errore interno del server');
        }
      });
  };


  const handleNuoveReazioni = (event) => {
    setReazioni(event.target.value);
  };

  const handleNuovoDestinatarioChange = (event) => {
    setNuovoDestinatario(event.target.value);
  };


  const columns = [
    { field: "id", headerName: "Id", width: 100 , headerClassName: 'custom-header', 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.id}</div>
    ),},
    { field: "testo", headerName: "Testo", width: 300 , headerClassName: 'custom-header', 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.testo}</div>
    ),},
    { field: "destinatario", headerName: "Destinatario", width: 200 , headerClassName: 'custom-header', 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.destinatario}</div>
    ),},
    { field: "mittente", headerName: "Mittente", width: 150 , headerClassName: 'custom-header', 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.mittente}</div>
    ),},
    { field: "categoria", headerName: "Categoria", width: 150, headerClassName: 'custom-header', 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.categoria}</div>
    ),},
    { field: "data", headerName: "Data", width: 150, headerClassName: 'custom-header', 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.data}</div>
    ), },
    { field: "Mod", headerName: "Mod", width: 150, headerClassName: 'custom-header', 
    renderCell: (params) => (
      <Button
      variant="contained"
      color="secondary"
      onClick={() => handleRowDoubleClick(params)}
      style={{background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}}
    >
      Open
    </Button>
    ), },
  ];

  const theme = createTheme({
    components: {
      MuiDataGrid: {
        styleOverrides: {
          columnHeader: {
            color: 'white',
          },
        },
      },
    },
  });

  const apprezzamentiColumns = [
    { field: "idMessaggio", headerName: "Id Squeal", width: 200,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.idMessaggio}</div>
    ), },
    { field: "mailUtente", headerName: "Mail Utente", width: 200, headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.mailUtente}</div>
    ),},
    { field: "giudizio", headerName: "Giudizio", width: 150, headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.reazione}</div>
    ),},
    { field: "Mod", headerName: "Mod", width: 150, headerClassName: 'custom-header', 
    renderCell: (params) => (
      <Button
      variant="contained"
      color="secondary"
      onClick={() => handleRowDoubleClickReazioni(params)}
      style={{background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}}
    >
      Open
    </Button>
    ), },
  ];

  const getRowId = (aprezzamento) => aprezzamento.idMessaggio;

  return (
    <div id="mod_sub_pages_squealel">
    <div id="divCloseWindow" onClick={handleClick}>
      <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
    </div>

    <div id="btnPage">
    <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'35vh' }} id="btnOnPage" onClick={showDiv1} >Apri tabella squealer</Button>
    <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh',width:'35vh' }} id="btnOnPage" onClick={showDiv2} >Apri tabella giudizi</Button>
    </div>

    {isDiv1Visible && (
    <div id="DataGridUserPage">
        <ThemeProvider theme={theme}>
          <DataGrid
            columns={columns}
            getColumnHeaderClassName={getColumnHeaderClassName}
            getRowClassName={getRowClassName}
            rows={userData}
            pageSize={5}

            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.8)', 
              color: 'black', 
            }}
          />
        </ThemeProvider>
      </div>)}
      
      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Dettagli Utente</DialogTitle>
        <DialogContent style={{marginTop:'2vh'}}>
            {selectedRow && (
              <div style={{textAlign:"justify"}}>
                <p><strong>Id:</strong> {selectedRow.id}</p>
                <p><strong>Mittente:</strong> {selectedRow.mittente}</p>
                <p><strong>Destinatario:</strong> {selectedRow.destinatario}</p>

              <Stack direction="column" spacing={2}>
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh' }} onClick={handleOpenChangeDestinatarioDialog}  variant="contained" color="secondary">
                  Cambia Destinatario
                </Button>
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', width:'15vh', alignSelf:'center', color:'white' }} onClick={() => setOpenDialog(false)}  color="secondary">
                  Annulla
                </Button>
              </Stack>
              </div>
             
            )}  
        </DialogContent> 
      </Dialog>

      <Dialog
         onClose={() => setOpenChangeDestinatarioDialog(false)} open={openChangeDestinatarioDialog}
      >
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Cambia Destinatario</DialogTitle>
        <DialogContent style={{marginTop:'2vh'}}>
          <TextField
            onChange={handleNuovoDestinatarioChange}
            value={nuovoDestinatario}
            label="Nuovo Destinatario"

          />
        </DialogContent>
        <DialogActions style={{ justifyContent: 'center' }}>
          <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}} onClick={handleSalvaDestinatario} variant="contained" color="secondary">
            Salva
          </Button>
          <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', alignSelf:'center'}} onClick={() => setOpenChangeDestinatarioDialog(false)} variant="contained" color="secondary">
            Annulla
          </Button>
        </DialogActions>
      </Dialog>
      {isDiv2Visible && (

      <div id="DataGridUserPage">
        <ThemeProvider theme={theme}>
          <DataGrid
            rows={appreciationData}
            pageSize={5}
            onRowDoubleClick={handleRowDoubleClickReazioni}

            getRowClassName={getRowClassName}
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.8)', 
              color: 'black', 
            }}
            columns={apprezzamentiColumns}
            getRowId={getRowId}

          />
        </ThemeProvider>
      </div>)}

      <ReazioniDialog
        onNuoveReazioni={handleNuoveReazioni}
        onClose={() => setOpenDialogPop(false)}
        open={openDialogPop}
        onCambiaReazioni={handleChangeReaction}
        reazioni={reazioni}

      />
    </div>
  );
};
export default VisualizzaSquealMod;
