
import Button from "@mui/material/Button";
import InputAdornment from "@mui/material/InputAdornment";
import DialogContent from "@mui/material/DialogContent";
import { DataGrid } from "@mui/x-data-grid";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import "./style.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import DialogTitle from "@mui/material/DialogTitle";
import { makeStyles } from "@mui/styles";
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import Box from "@mui/material/Box";

import DialogContentText from "@mui/material/DialogContentText";


const useStyles = makeStyles((theme) => ({
  dialog: {
    width: "100vw",
    height: "100vh",
    padding: "25vh",
    textAlign: "center",
    [theme.breakpoints.down("sm")]: {
      padding: "7vh",
      width: "100vw",
      height: "100vh",
    },
  },
  label: {
    width: "20vw",
    [theme.breakpoints.down("sm")]: {
      width: "50vw",
    },
  },
  stack: {
    margin: "5vh",
    [theme.breakpoints.down("sm")]: {
      marginLeft: "10vw",
      marginTop: "2vh",
    },
  },
}));


const GestioneUtentiMod= ({ handleClick }) => {
  const [userData, setUserData] = useState([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [charValue, setCharValue] = useState("");
  const [selectedRow, setSelectedRow] = useState(null);

  const classes = useStyles();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get("http://localhost:3001/api/get");
        setUserData(response.data);
      } catch (error) {
        console.error("Errore durante la richiesta API:", error);
      }
    };

    fetchData();
  }, []);

  const handleAddChar = async () => {
    try {
      const response = await axios.post(
        "http://localhost:3001/post/AggiuntaChar",
        {
          mail: selectedRow.email,
          newChar: charValue,
        }
      );

      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
    setOpenDialog(false);
  };

  const handleBlockUser = async (mail) => {
    try {
      const response = await axios.put(
        `http://localhost:3001/api/utenti/${mail}/stato`,
        { stato: "bloccato" }
      );

      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleUnblockUser = async (mail) => {
    try {
      const response = await axios.put(
        `http://localhost:3001/api/utenti/${mail}/stato`,
        { stato: "sbloccato" }
      );

      const updatedResponse = await axios.get("http://localhost:3001/api/get");
      setUserData(updatedResponse.data);
    } catch (error) {
      console.error(error);
    }
  };


  const getRowId = (user) => user.email;

  const getRowClassName = () => "white-row";

  const getColumnHeaderClassName = () => "white-column-header";

  const columns = [
    { field: "mail", headerName: "Mail", width: 200,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.email}</div>
    ), },
    { field: "nome", headerName: "Nome", width: 150,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.nome}</div>
    ), },
    { field: "cognome", headerName: "Cognome", width: 150,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.cognome}</div>
    ), },
    { field: "tipoUtente", headerName: "Tipologia", width: 150,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.tipoUtente}</div>
    ), },
    { field: "CaratteriGiornalieri", headerName: "CaratteriGiornalieri", width: 150,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.CaratteriGiornalieri}</div>
    ), },
    { field: "CaratteriSettimanali", headerName: "CaratteriSettimanali", width: 150,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.CaratteriSettimanali}</div>
    ), },
    { field: "CaratteriMensili", headerName: "CaratteriMensili", width: 150,headerClassName: 'custom-header',
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.CaratteriMensili}</div>
    ), },

    {
      headerName: "Blocca",
      field: "blocca",
      headerClassName: 'custom-header',
      width: 100,
      renderCell: (params) => {
        if (params.row.stato === 'sbloccato') {
          return (
            <Button
              onClick={() => handleBlockUser(params.row.email)}
              variant="contained"
              style={{ background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius: '10px', height: '5vh', width: '15vh', alignSelf: 'center' }}
              color="primary"

            >
              Blocca
            </Button>
          );
        } else {
          return null;
        }
      },
    },
    {
      headerName: "Sblocca",
      field: "sblocca",
      headerClassName: 'custom-header',
      width: 100,
      renderCell: (params) => {
        if (params.row.stato === 'bloccato') {
          return (
            <Button
              onClick={() => handleUnblockUser(params.row.email)}
              variant="contained"
              style={{ background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius: '10px', height: '5vh', width: '15vh', alignSelf: 'center' }}
              color="secondary"
            >
              Sblocca
            </Button>
          );
        } else {
          return null;
        }
      },
    },
    {
      field: "ADD CARATTERI",
      headerName: "ADD CARATTERI",
      headerClassName: 'custom-header',
      width: 100,
      renderCell: (params) => (
        <Button
        onClick={() => handleRowDoubleClick(params)}
          variant="contained"
          style={{background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}}
          color="secondary"

        >
          Open
        </Button>
      ),
    },
  ];

  const theme = createTheme({
    components: {
      MuiDataGrid: {
        styleOverrides: {
          columnHeader: {
            color: "white",
          },
        },
      },
    },
  });

  const handleRowDoubleClick = (params) => {
    setSelectedRow(params.row);
    setOpenDialog(true);
  };

  return (
    <div id="mod_sub_pages_GestioneUtentiMod">
      <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon  size={20} />
      </div>
      <div id="DataGridUserPage">
        <ThemeProvider theme={theme}>
          <DataGrid
            getRowId={getRowId}
            columns={columns}
            getRowClassName={getRowClassName}
            rows={userData}

            getColumnHeaderClassName={getColumnHeaderClassName}
            style={{
              backgroundColor: 'rgba(255, 255, 255, 0.8)', 
              color: 'black', 
            }}
            pageSize={5}

          />
        </ThemeProvider>
      </div>
      
      <Dialog className={classes.dialog} open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>Dettagli Utente</DialogTitle>
        <DialogContent style={{marginTop:'2vh'}}>
          <DialogContentText>
            {selectedRow && (
              <div>
                <p><b>Email:</b> {selectedRow.email}</p>
                <Box display="flex" alignItems="center" flexDirection="column">
                <TextField
                  sx={{ m: 1, width: "25ch" }}
                  label="Aumenta Caratteri"

                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start"></InputAdornment>
                    ),
                  }}
                  onChange={(e) => setCharValue(e.target.value)}
                  id="Char"
                  value={charValue}
                />
                <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh', alignContent:'center' }} onClick={handleAddChar} variant="contained" color="secondary">
                Aggiungi Char
                </Button>
              </Box>
              </div>
            )}
          </DialogContentText>
        </DialogContent>
       
      </Dialog>
    </div>
  );
};

export default GestioneUtentiMod;
