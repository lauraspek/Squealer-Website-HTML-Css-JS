import React, { useEffect, useState } from "react";
import PropTypes from 'prop-types';
import { styled } from '@mui/material/styles';
import Stack from '@mui/material/Stack';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import StepConnector, { stepConnectorClasses } from '@mui/material/StepConnector';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import { IconButton, Select, MenuItem,Menu  , FormControl, InputLabel, Card, CardContent, CardActionArea, Typography, Button } from '@mui/material';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import axios from 'axios';
import Home from './Homepage';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';



const cardStyle = {
  display: 'flex',
  justifyContent: 'center',
  width: '90%',
  color: 'black',

};

const selectLabelStyle = {
  color: '#fff',
};


const QontoConnector = styled(StepConnector)(({ }) => ({
  [`&.${stepConnectorClasses.alternativeLabel}`]: {
    top: 10,
    left: 'calc(-50% + 16px)',
    right: 'calc(50% + 16px)',
  },
  [`&.${stepConnectorClasses.active}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: '#784af4',
    },
  },
  [`&.${stepConnectorClasses.completed}`]: {
    [`& .${stepConnectorClasses.line}`]: {
      borderColor: '#784af4',
    },
  },
}));




const steps = ['Visualizza Canali', 'Seleziona Canali da acquistare', 'Conferma pagamento'];

const AcquistaCanale = ({ handleClick }) => {
  const [selectedChannels, setSelectedChannels] = useState([]);
  const [activeStep, setActiveStep] = React.useState(0);
  const [userData, setUserData] = useState([]);
  const [totalCost, setTotalCost] = useState(0);

  useEffect(() => {
    axios
      .get("http://localhost:3001/get/canaliMinSquealer")    //prendo tutti i canali personali
      .then((response) => {
        setUserData(response.data);
      })
      .catch((error) => {
        console.error("Errore durante la richiesta API:", error);
      });
  }, []);

  const handleNext = () => {
    if (activeStep === 1) {
      const total = 20;
      setTotalCost(total);
    }
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleSelectChange = (event) => {
    const selectedChannelsValue = event.target.value;
    setSelectedChannels(selectedChannelsValue);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const acquirente = localStorage.getItem('email');

  const handleReset = async (e) => {

    setActiveStep(0);
    setSelectedChannels([]);
    setTotalCost(0);

  
    if (selectedChannels.length === 0) {
      alert("Seleziona almeno un canale prima di inviare la richiesta di acquisto.");
      return; 
    }

    try {
      const response = await axios.post(`http://localhost:3001/post/richiestaAcquisto/${acquirente}`, {   //aggiungo la richiesta 
        canale: selectedChannels,
      });
      console.log('Risposta dalla stored procedure:', response.data);
      alert("Richiesta di acquisto effettuata correttamente");
    } catch (error) {
      console.error(error);
    } 
    handleClick();

  };
 




  const selectStyle = {
    color: '#fff',
    '&:before': {
      borderColor: '#fff',
    },
    '&:after': {
      borderColor: '#fff',
    },
  };

 
 

 

  return (
    <div id="vip_sub_pages">
        <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <Stack sx={{ width: '100%' }} spacing={4}>
          <Stepper alternativeLabel activeStep={activeStep} connector={<QontoConnector />}>
            {steps.map((label, index) => (
              <Step key={label}>
                <StepLabel  id="carrello-step-label">{label}</StepLabel>
              </Step>
            ))}
          </Stepper>

          <div id="carrello-riepilogo">
            {activeStep === 0 && (
                 <CardContent>
                   <Typography gutterBottom variant="h5" component="div" textAlign="center" > 
                     Stai per acquistare un canale!!!
                   </Typography>
                 </CardContent>
            )}
          
     
          {activeStep === 1 && (
             <Card sx={cardStyle}>

                 <Typography gutterBottom variant="h5" component="div">
                   Seleziona canali da acquistare:
                 </Typography>
                 <FormControl fullWidth>
                   <InputLabel id="select-multiple-label" sx={selectLabelStyle}>Seleziona Canali</InputLabel>
                   <Select
                     labelId="select-multiple-label"
                     id="select-multiple"
                     value={selectedChannels}
                     onChange={handleSelectChange}
                     sx={selectStyle}
                     MenuComponent={Menu}
                   >
                     {userData.map((channel, index) => (
                       <MenuItem key={index} value={channel.nome}>
                         {channel.nome}
                       </MenuItem>
                     ))}
                   </Select>
                 </FormControl>
 
           </Card>
            )}

          {activeStep === 2 && (
              <Card style={{ display: 'flex', justifyContent: 'center', width: '90%' }}>
              <CardActionArea>
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    Riepilogo:
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Canali selezionati:
                    <ul>
                      <li>{selectedChannels}</li>
                    </ul>
                    Costo totale: {totalCost} euro
                  </Typography>
                  <Button style={{ background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'14px',height:'5vh', marginTop: '8px', width:'70vh' }} variant="contained" color="secondary" onClick={handleReset}>
                    Paga
                  </Button>
                </CardContent>
              </CardActionArea>
            </Card>
          )}
        </div>
        <div style={{ display: 'flex', justifyContent: 'center', marginTop: '16px' }}>
              <IconButton disabled={activeStep === 0} onClick={handleBack}>
                <ArrowBackIosIcon sx={{ color: '#fff' }} />
              </IconButton>
              <IconButton disabled={activeStep === steps.length - 1} onClick={handleNext}>
                <ArrowForwardIosIcon sx={{ color: '#fff' }} />
              </IconButton>
            </div>
          </Stack>
        </div>
      </div>
  );
}
export default AcquistaCanale;