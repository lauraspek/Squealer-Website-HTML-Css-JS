import CardContent from "@mui/material/CardContent";
import Typography from '@mui/material/Typography';
import Button from "@mui/material/Button";
import OutlinedInput from '@mui/material/OutlinedInput';
import { Card } from "@mui/material";
import CardActionArea from '@mui/material/CardActionArea';
import React, { useState } from "react";
import FormControl from '@mui/material/FormControl';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import "./style.css";
import axios from "axios";



const CreazioneCanale = ({ handleClick }) => {

    const [nameChannel, setNameChannel] = useState('');
    const [description, setDescription] = useState('');



    const handleChangeDescription = (event) => {
        setDescription(event.target.value);
    };

    const handleChangeName = (event) => {
      setNameChannel(event.target.value);
  };

    const creatore = localStorage.getItem('email');

    const handleCreaCanale = async (e) => {
  
      try {
        const response = await axios.post(`http://localhost:3001/post/nuovoCanale/${creatore}`, {   //crea un nuovo canale
          nomeCanale: nameChannel,
          descrizioneCanale: description
        });
        alert("Canale creato con successo!");
      } catch (error) {
        console.error(error);
      } 
      handleClick();

    };

    

    return(

        <div id="vip_sub_pages">
          <div  onClick={handleClick} id="divCloseWindow">
        <HighlightOffIcon size={20} sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }}  /></div>
                  

            <h2 style={{position:'relative',fontSize:'4vh',marginBottom: "20px", top:'18vh', fontStyle:'italic',  fontFamily:'Trebuchet MS, Lucida Sans Unicode, Lucida Grande,Lucida Sans, Arial, sans-serif'}}>Crea un nuovo canale</h2>

            <Card sx={{  opacity:'0.8', width:'75%', display: 'flex',    top:'18vh', left:'12vh', position:'relative',justifyContent: 'center', borderRadius:'20px'}}>
                <CardActionArea>
                  <CardContent>

                    <Typography component="div" gutterBottom variant="h5" style={{ position:'relative' ,top:'5.5vh',right:'18vh' , }}  >
                      Nome Canale:
                    </Typography>
                    <FormControl  variant="outlined" sx={{  width:'50vh', display: 'flex', left:'28vh', flexDirection: 'row', position:'relative' , m: 1,  }}>
                        <OutlinedInput
                            onChange={handleChangeName}
                            value={nameChannel}
                            aria-describedby="outlined-weight-helper-text"
                            id="outlined-adornment-weight"
                            sx={{marginRight: '10px'}}
                            inputProps={{
                            'aria-label': 'weight',
                            }}
                        />
                    </FormControl>

                    <Typography  gutterBottom variant="h5" component="div" style={{ top:'4.5vh', position:'relative', right:'20vh'}} >
                      Descrizione canale:
                    </Typography>
                    <FormControl sx={{ bottom:'1vh',   display: 'flex',left:'28vh',  position:'relative' , flexDirection: 'row' , width:'50vh', m: 1}} variant="outlined">
                      <OutlinedInput
                            onChange={handleChangeDescription}
                            aria-describedby="outlined-weight-helper-text"
                            id="outlined-adornment-weight"
                            sx={{marginRight: '10px'}}
                            value={description}
                            inputProps={{
                            'aria-label': 'weight',
                            }}
                        />
                    </FormControl>

                    <Button color="secondary" style={{height:'5vh', marginTop:'2vh' , background: 'linear-gradient(to right, #000000, #5e071a)', color:'white', }} variant="contained"  sx={{ mt: 1, mr: 1 }}  onClick={handleCreaCanale}>
                        Continue
                    </Button>
                  </CardContent>
                </CardActionArea>
            </Card></div>

    );

};

export default CreazioneCanale;