import React from 'react';
import './style.css';
import { useState } from 'react';
import { Button, Dialog, DialogTitle, TextField, Stack } from '@mui/material';
import axios from 'axios';
import { makeStyles } from '@mui/styles';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

const useStyles = makeStyles((theme) => ({
  dialog:{
    width: '100vw',
    height: '100vh',
    padding: '25vh',
    textAlign: 'center',
    [theme.breakpoints.down('sm')]: {
      padding: '7vh',
      width: '100vw',
      height: '100vh',
    },
  },
  label:{
    width:'20vw',
    [theme.breakpoints.down('sm')]: {
      width:'50vw',
    },
  },
  stack:{
    margin:'5vh',
    [theme.breakpoints.down('sm')]: {
      marginLeft:'10vw', 
      marginTop:'2vh',
    },
  },
}));

const ProfiloUtente= ({ handleClick }) => {

  const [modificaPassword, setModificaPassword] = useState(false);
  const [newPassword, setNewPassword] = useState('');

  const username = localStorage.getItem('email');
  const name = localStorage.getItem('name');
  const password = localStorage.getItem('password');
  console.log("nome: " + name);


  const classes = useStyles();


  function handleOpenChangePassword() {
    setModificaPassword(true);
  }

  function handleCloseChangePassword() {
    setModificaPassword(false);
  }

  const handleChangePassword = async (e) => {
    try {
      const response = await axios.post('http://localhost:3001/changePassword', {
        username,
        oldPassword: password,
        newPassword,
      });

    } catch (error) {
      console.error(error);
    }
    localStorage.setItem('password', newPassword);
    handleClick();
  };


  return (
    <div>

<div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>
      <div id="user_container_vip">
        <div id='user_info_container_vip'>
          <div id='container-logo'></div>


          <h2  id="title_impostazioni_vip">Il mio profilo</h2>

          <div id='user_info_container_content_vip'>
            <div id="infoLabel">
              <div className='single-info'>
                <p className='row-title'>Username:</p>
                <p className='row-content'>{username}</p>
              </div>

              <div className='single-info'>
                <p className='row-title'>Nome:</p>
                <p className='row-content'>{name}</p>
              </div>


              <div className='single-info'>
                <p className='row-title'>Password:</p>
                <p className='row-content'>{password}</p>
              </div>

              <p id='lbl-modifica-pw'> Modifica password <a onClick={handleOpenChangePassword}>Clicca qui</a></p>
            </div>


          </div>
        </div>
      </div>

      <Dialog style={{ position:'relative', left:'5vh' }} className={classes.dialog} open={modificaPassword}>
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}> Cambia Password </DialogTitle>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <TextField style={{ width:'27vh', marginTop:'5vh',marginLeft:'5vh',marginRight:'5vh' }} className={classes.label} variant='outlined' value={newPassword} label="Inserire nuova password" onChange={(e) => setNewPassword(e.target.value)} />
        </div>
        <Stack className={classes.stack} direction="column" spacing={2}>
          <Button style={{ background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh' }} variant="contained" color="secondary" onClick={handleChangePassword}>Cambia</Button>
          <Button style={{ background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'15vh', alignSelf:'center'}} variant="contained" color="secondary" onClick={handleCloseChangePassword}>Annulla</Button>
        </Stack>
      </Dialog>
    </div>
  );
};

export default ProfiloUtente;
