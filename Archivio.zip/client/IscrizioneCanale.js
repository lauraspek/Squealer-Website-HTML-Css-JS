import { useTheme, useMediaQuery } from '@mui/material';
import React, { useState, useEffect } from 'react';
import { makeStyles } from '@mui/styles';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import {Button,Typography,Card,CardHeader,CardContent,Avatar,} from '@mui/material';
import axios from 'axios';

const useStyles = makeStyles(() => ({
  card: {width: '100%',borderRadius: 16,boxShadow: '0 8px 16px 0 #BDC9D7',overflow: 'hidden',},
  cardContent: {fontSize: '2px',},
  header: {fontFamily: 'Barlow, san-serif',backgroundColor: '#fff',padding: '3vh',textAlign: 'center',},
  headline: {color: '#122740',fontSize: '1.25rem',fontWeight: 600,},
  link: {color: '#2281bb',padding: '0 0.25rem',fontSize: '0.875rem',},
  actions: {color: '#BDC9D7',},
  divider: {backgroundColor: '#f0f8ff',margin: '0 20px',},
  search: {marginTop: 'auto',borderRadius: '25px',borderColor: '2px solid black',height: '2vw',},
  input: {marginTop: '1vh',borderRadius: '25px',borderColor: '2px solid black',height: '2vw',padding: '1vh',},
  btn: {borderRadius: 20,padding: '0.125rem 0.75rem',borderColor: '#becddc',fontSize: '0.75rem',margin: '1vw',color: 'black',},
  avatar: {width: 48,height: 48,backgroundColor: '#f0f0f0',color: '#333',fontSize: '1.5rem',},
  followButton: {backgroundColor: 'blue',color: 'white','&:hover': {backgroundColor: 'darkblue',},
  }
}));





const IscrizioneCanale = ({ handleClick }) => {
  const theme = useTheme();

  const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));
  const email = localStorage.getItem('email');
  const [channelProp, setChannelProp] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [channel, setChannel] = useState([]);

  const classes = useStyles();


  useEffect(() => {
    axios
      .get(`http://localhost:3001/canaliIscrittoUtente/${email}`)
      .then((response) => {
        setChannelProp(response.data);
      })
      .catch((error) => {
        console.error('Errore durante la richiesta API:', error);
      });
  }, [email]);


  useEffect(() => {
    axios
      .get(`http://localhost:3001/canaliNonIscrittoUtente/${email}`)
      .then((response) => {
        setChannel(response.data);
      })
      .catch((error) => {
        console.error('Errore durante la richiesta API:', error);
      });
  }, [email]);


  useEffect(() => {
    if (searchQuery) {
      axios
        .get(`http://localhost:3001/search/canaliSquealer?query=${searchQuery}`)
        .then((response) => {
          setChannel(response.data);
        })
        .catch((error) => {
          console.error('Errore durante la ricerca dei canali:', error);
        });
    } else {
      axios
        .get(`http://localhost:3001/canaliNonIscrittoUtente/${email}`)
        .then((response) => {
          setChannel(response.data);
        })
        .catch((error) => {
          console.error('Errore durante la richiesta API:', error);
        });
    }
  }, [searchQuery]);





  const handleAddFollow = async (canale) => {
    try {
      const response = await axios.post(`http://localhost:3001/post/canaliIscritti/${email}`, {   //aggiungiamo il follow al canale
        nomeCanale: canale,
      });

      if (response.status === 200) {
        const updatedResponse = await axios.get(`http://localhost:3001/canaliIscrittoUtente/${email}`);   //prendiamo di nuovo i canali iscritti aggiornati
        setChannelProp(updatedResponse.data);

        const updatedResponse2 = await axios.get(`http://localhost:3001/canaliNonIscrittoUtente/${email}`);   //prendiamo di nuovo i canali non iscritti aggiornati
        setChannel(updatedResponse2.data);
      }
    } catch (error) {
      console.error(error);
    }
  };



  const handleUnfollow = async (canale) => {
    try {
      const response = await axios.delete(`http://localhost:3001/delete/canaliIscritti/${email}`, {   //aggiungiamo il unfollow al canale
        data: { nomeCanale: canale }, 
      });
  
      if (response.status === 200) {
        const updatedResponse = await axios.get(`http://localhost:3001/canaliIscrittoUtente/${email}`);   //prendiamo di nuovo i canali iscritti aggiornati
        setChannelProp(updatedResponse.data);

        const updatedResponse2 = await axios.get(`http://localhost:3001/canaliNonIscrittoUtente/${email}`);   //prendiamo di nuovo i canali non iscritti aggiornati
        setChannel(updatedResponse2.data);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const calculateFontSize = () => {
    if (isSmallScreen) {
      return '0.75rem'; 
    } else {
      return '1rem'; 
    }
  };


  return (
    <div  id="vip_sub_pages">
        <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={25} />
      </div>
          <div className="mod-header-logo"></div>

      <div id="container-new-follow" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width:'100%' }}>
        <Card style={{ maxHeight: '70vh',  border: '2px solid rgba(255, 255, 255, 0.3)', overflowY: 'auto',   width:'150vw', height:'15vh', position:'relative', bottom:'3vh', left:'19vh', backgroundColor:'transparent',color:'white'}}>
          <CardHeader style={{ fontStyle:'italic', opacity: '0.6'}} title="Lista dei Canali" />
          <CardContent className={classes.cardContent}>
            {channel.map((canale, index) => (
              canale.nome && (
                <div key={canale.nome} style={{ display: 'flex', alignItems: 'center', marginBottom: '3vh', paddingBottom:'1vh', borderBottom: '2px solid rgba(255, 255, 255, 0.3)'}}>
                  <Avatar style={{ borderRadius: '10px', backgroundColor:'black', color:'#5e071a'}}>
                    {typeof canale.nome === 'string' && canale.nome.length > 0 ? canale.nome.charAt(0) : 'N'}
                  </Avatar>
                  <Typography style={{ flex: 1,  fontSize: calculateFontSize(), marginLeft: '1rem' }}>{canale.nome}</Typography>
                  <Button style={{backgroundColor:'white', color:'#5e071a'}} variant="contained" onClick={() => handleAddFollow(canale.nome)}>
                    Follow
                  </Button>
                </div>
              )
            ))}
          </CardContent>
        </Card>


 <Card style={{ maxHeight: '70vh', overflowY: 'auto', height: '40vh', width: '100vw', position: 'relative', top: '36vh', right: '30vh', backgroundColor: 'transparent', color: 'white',border: '2px solid rgba(255, 255, 255, 0.3)' }} >
    <CardHeader style={{ fontStyle: 'italic', color: 'white', opacity: '0.6' }} title="Canali Seguiti" />
          <CardContent className={classes.cardContent}>
            {channelProp.map((canale) => (
              canale.nome && (
                <div key={canale.nome} style={{ display: 'flex', alignItems: 'center', marginBottom: '3vh', paddingBottom:'1vh',borderBottom: '2px solid rgba(255, 255, 255, 0.3)' }}>
                  <Avatar style={{ borderRadius: '10px' , backgroundColor:'black', color:'#5e071a'}}>
                    {typeof canale.nome === 'string' && canale.nome.length > 0 ? canale.nome.charAt(0) : 'N'}
                  </Avatar>
                  <Typography style={{flex: 1, fontSize: calculateFontSize(),marginLeft: '1rem',   }}>{canale.nome}</Typography>
                  <Button style={{backgroundColor:'white', color:'#5e071a'}} variant="contained" onClick={() => handleUnfollow(canale.nome)}>
                    Unfollow
                  </Button>
                </div>
              )
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default IscrizioneCanale;
