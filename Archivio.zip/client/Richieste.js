import React, { useEffect, useState } from "react";
import axios from "axios";
import { DataGrid } from "@mui/x-data-grid";
import Button from "@mui/material/Button";
import "./style.css";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Home from "./Homepage";
import { Box } from "@mui/material";
import Typography from "@mui/material/Typography";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import useMediaQuery from "@mui/material/useMediaQuery";
import IconButton from "@mui/material/IconButton";
import MenuIcon from '@mui/icons-material/Menu';
import DoneIcon from '@mui/icons-material/Done';
import ClearIcon from '@mui/icons-material/Clear';
import Drawer from "@mui/material/Drawer";
import {Divider, List, ListItem, ListItemButton, ListItemText } from "@mui/material";


const Richieste = ({ handleClick }) => {

  const [userData, setUserData] = React.useState([]);
  const [richiesteRifiutate, setRichiesteRifiutate] = React.useState([]);
  const [richiesteAccettate, setRichiesteAccettate] = React.useState([]);
  const [exitBtn, setExitBtn] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [dialogAccettate, setDialogAccettate] = React.useState(false);
  const [dialogRifiutate, setDialogRifiutate] = React.useState(false);

  const username = localStorage.getItem("username");

  const drawerWidth = 300;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [acquistoResponse, rifiutateResponse, accettateResponse] = await Promise.all([
          axios.get(`http://localhost:3001/get/richiesteAcquisto/${username}`),
          axios.get(`http://localhost:3001/get/richiesteRifiutate/${username}`),
          axios.get(`http://localhost:3001/get/richiesteAccettate/${username}`),
        ]);

        setUserData(acquistoResponse.data);
        setRichiesteRifiutate(rifiutateResponse.data);
        setRichiesteAccettate(accettateResponse.data);
      } catch (error) {
        console.error("Errore durante le richieste API:", error);
      } 
    };

    fetchData();
  }, [username]);


  const handleOpenDialog = (type) => {
    if (type === "accettate") {
      setDialogAccettate(true);
    } else if (type === "rifiutate") {
      setDialogRifiutate(true);
    }
  };

  const handleCloseDialog = () => {
    setDialogAccettate(false);
    setDialogRifiutate(false);
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  // Usa il hook useMediaQuery per verificare se lo schermo è piccolo
  const isSmallScreen = useMediaQuery((theme) => theme.breakpoints.down("sm"));

  const handleExitBtn = () =>{
    setExitBtn(true);
  }

  if (exitBtn) {
    // Render logged-in state
    return (
      <div>
        <Home />
      </div>
    );
  }

  const getRowId = (channel) => channel.canale;

  const getRowClassName = (params) => {
    return "white-row";
  };

  const getColumnHeaderClassName = (params) => {
    return "white-column-header";
  };

  const handleAccettaAcquisto = async (idRichiestaAcquisto, canale, nuovoProprietario) => {
    try {
      const response = axios.put(`http://localhost:3001/put/modificaEsito/${idRichiestaAcquisto}`, {
        newEsito: "accettata",
      });
  
      console.log("Risposta dalla stored procedure:", response.data);
      alert("Acquisto accettato con successo!");
      setRichiesteAccettate((prevAccettate) => prevAccettate.filter((notification) => notification.id !== idRichiestaAcquisto));

      const updatedResponse = await  axios.get(`http://localhost:3001/get/richiesteAccettate/${username}`);
      setRichiesteAccettate(updatedResponse.data);
     
    } catch (error) {
      console.error(error);
    }
  
    cambiaProprietario(canale, nuovoProprietario);
  };
  

  const cambiaProprietario = (canale, nuovoProprietario) => {
    try {
      const response = axios.put(`http://localhost:3001/put/modificaProprietario/${canale}`, {
        newProprietario: nuovoProprietario,
      });

      console.log("Risposta dalla stored procedure:", response.data);
      
    } catch (error) {
      console.error(error);
    }
  };

  const handleRifiutaAcquisto = async (idRichiestaAcquisto) => {
    try {
      // Rimuovi la richiesta rifiutata dalla lista delle richieste accettate
      setRichiesteAccettate((prevAccettate) => prevAccettate.filter((notification) => notification.id !== idRichiestaAcquisto));
  
      const response = axios.put(`http://localhost:3001/put/modificaEsito/${idRichiestaAcquisto}`, {
        newEsito: "rifiutata",
      });
  
      console.log("Risposta dalla stored procedure:", response.data);
      alert("Richiesta rifiutata con successo!");


      const updatedResponse = await axios.get(`http://localhost:3001/get/richiesteRifiutate/${username}`);
      setRichiesteRifiutate(updatedResponse.data);
  

    } catch (error) {
      console.error(error);
    }
  };
  

  const columns = [
    { field: "id", headerName: "Id", width: 100,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.id}</div>
    ), },
    { field: "canale", headerName: "Canale", width: 200,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.canale}</div>
    ), },
    { field: "acquirente", headerName: "Acquirente", width: 150 ,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.acquirente}</div>
    ),},
    { field: "esito", headerName: "Esito", width: 150,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.esito}</div>
    ), },
    {
      field: "accetta",
      headerName: "Accetta",
      headerClassName: 'custom-header',
      width: 100,
      renderCell: (params) => (
        <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh' }} variant="contained" color="primary" onClick={() => handleAccettaAcquisto(params.row.id, params.row.canale, params.row.acquirente)}>
          Accetta
        </Button>
      ),
    },
    {
      field: "rifiuta",
      headerName: "Rifiuta",
      headerClassName: 'custom-header',
      width: 100,
      renderCell: (params) => (
        <Button style={{ marginTop:'2vh',background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px',height:'5vh' }} variant="contained" color="secondary" onClick={() => handleRifiutaAcquisto(params.row.id)}>
          Rifiuta
        </Button>
      ),
    },
  ];

  const columnsAccettateRifiutate = [
    { field: "id", headerName: "Id", width: 100,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.id}</div>
    ),  },
    { field: "canale", headerName: "Canale", width: 200 ,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.canale}</div>
    ), },
    { field: "acquirente", headerName: "Acquirente", width: 150 ,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.acquirente}</div>
    ), },
    { field: "esito", headerName: "Esito", width: 150 ,  headerClassName: 'custom-header' , 
    renderCell: (params) => (
      <div style={{ color: 'black' }}>{params.row.esito}</div>
    ), },
  ];

  const theme = createTheme({
    components: {
      MuiDataGrid: {
        styleOverrides: {
          columnHeader: {
            color: "white",
          },
        },
      },
    },
  });

  const handleCloseAccettate = () => {
    setDialogAccettate(false);
  };
  
  const handleCloseRifiutate = () => {
    setDialogRifiutate(false);
  };

  const handleClosePages = () => {
    setMobileOpen(false); 
  };

  const navItems = [
    {
      text: 'Richieste Accettate',
      icon: <DoneIcon />,
      onClick: () => handleOpenDialog("accettate"),
    },
    {
      text: 'Richieste Rifiutate',
      icon: <ClearIcon />,
      onClick: () => handleOpenDialog("rifiutate"),
    },
  ];


  return (
    <>
          <div id="divCloseWindow" onClick={handleClick}>
        <HighlightOffIcon sx={{ color: theme => theme.palette.mode === 'dark' ? 'black' : 'white' }} size={20} />
      </div>
      <div  id="vip_sub_pages">
      <Box>
            {isSmallScreen ? (
              // Icona del menu per schermi piccoli
              <IconButton edge="start" color="inherit" aria-label="menu" onClick={handleDrawerToggle}>
                <MenuIcon />
              </IconButton>
            ) : (
              // Pulsanti standard per schermi più grandi
              <div>
                <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'38vh', marginRight:'2vh', marginTop:'1vh' }}color="inherit" onClick={() => handleOpenDialog("accettate")}>
                  Richieste Accettate
                </Button>
                <Button style={{ color: 'white', background: 'linear-gradient(to right, #000000, #5e071a)', borderRadius:'10px' ,height:'5vh', width:'38vh', marginTop:'1vh' }} color="inherit" onClick={() => handleOpenDialog("rifiutate")}>
                  Richieste Rifiutate
                </Button>
              </div>
            )}
      </Box>

      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1, color: "white",  marginTop:'2vh'  }}>
          Richieste acquisto canale
        </Typography>
        <div id="DataGridNotification">
          <ThemeProvider theme={theme}>
            <DataGrid
              rows={userData}
              columns={columns}
              pageSize={5}
              getRowId={getRowId}
              getRowClassName={getRowClassName}
              getColumnHeaderClassName={getColumnHeaderClassName}
              rowHeight={40}
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.8)', 
                color: 'black', 
                
              }}
            />
          </ThemeProvider>
        </div>
      </div>


      <Dialog  open={dialogAccettate} onClose={handleCloseAccettate}>
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>{"Richieste Accettate"}</DialogTitle>
        <IconButton
      aria-label="close"
      style={{ position: 'absolute', right: '2vh', top: '1vh', color: 'white' }}
      onClick={handleCloseAccettate}
    >
      <HighlightOffIcon />
    </IconButton>
        <DialogContent style={{ marginTop: '2vh' }}>
          <DialogContentText>
            <div>
              <ThemeProvider theme={theme}>
              <div>
                <DataGrid
                  rows={richiesteAccettate}
                  columns={columnsAccettateRifiutate}
                  pageSize={5}
                  
                  getRowId={getRowId}
                  getRowClassName={getRowClassName}
                  getColumnHeaderClassName={getColumnHeaderClassName}
                  rowHeight={40}
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.8)', 
                    color: 'black', 
                    width:'70vh',
                    height:'auto'
                  }}
                />
                </div>
              </ThemeProvider>
            </div>
          </DialogContentText>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogRifiutate} onClose={handleCloseRifiutate}>
        <DialogTitle style={{ background: 'linear-gradient(to right, #000000, #5e071a)', color: 'white', fontStyle:'italic' }}>{"Richieste Rifiutate"}</DialogTitle>
        <IconButton
      aria-label="close"
      style={{ position: 'absolute', right: '2vh', top: '1vh', color: 'white' }}
      onClick={handleCloseAccettate}
    >
      <HighlightOffIcon />
    </IconButton>
        <DialogContent>
          <DialogContentText>
            <div>
              <ThemeProvider theme={theme}>
              <div >
                <DataGrid
                  rows={richiesteRifiutate}
                  columns={columnsAccettateRifiutate}
                  pageSize={5}
                 
                  getRowId={getRowId}
                  getRowClassName={getRowClassName}
                  getColumnHeaderClassName={getColumnHeaderClassName}
                  rowHeight={40}
                />
                </div>
              </ThemeProvider>
            </div>
          </DialogContentText>
        </DialogContent>
      </Dialog>

      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
          },
        }}
      >
        <Typography variant="h6" sx={{ my: 2, textAlign: 'center' }}>
          User Menu
        </Typography>
        <Divider />
        <List>
          {navItems.map((item) => (
            <ListItem key={item.text} disablePadding>
              <ListItemButton onClick={() => {
                handleClosePages();
                item.onClick();
              }} style={item.style}>
                {item.icon}
                <ListItemText primary={item.text} className="mod-menu-item" />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>
      </div>

    </>
  );
};

export default Richieste;
