const express = require('express'); 
const bodyParser = require('body-parser'); 
const cors = require('cors');
const app = express();
const mysql = require('mysql');
const multer  = require('multer');

const db = mysql.createPool({
  host: 'localhost', // L'indirizzo IP o il nome host del tuo database
  user: 'root', // Il nome utente del tuo database
  password: 'Si51Mo30', // La password del tuo database
  database: 'squealerdb', // Il nome del tuo database
});  


app.use(bodyParser.urlencoded({extended: true})); 
app.use(express.json());
app.use(cors());

app.get('/', (req, res) => {
  res.send('Write API Path');
});



app.get('/api/get/:mail', (req, res) => {
  const email = req.params.mail;
  const sql = `
    SELECT * 
    FROM utente 
    WHERE email = ?;
  `;

  db.query(sql, [email], (err, result) => {
    if (err) {
      console.error('Errore nella query: ' + err);
      res.status(500).json({ error: 'Errore nel server.' });
    } else {
      res.status(200).json(result);
    }
  });
});

app.get('/api/getModeratore', (req, res) => {
  const sql = 'SELECT * FROM Moderatore';
  db.query(sql, (err, result)=>{
      res.send(result);
  })
});

app.get('/api/get', (req, res) => {
  const sql = 'SELECT * FROM utente';
  db.query(sql, (err, result)=>{
      res.send(result);
  })
});




app.get('/api/getVip', (req, res) => {
  const sql = 'SELECT * FROM Vip';
  db.query(sql, (err, result)=>{
      res.send(result);
  })
});



//GET /messages - Recupera tutti i messaggi dal database e li restituisce come JSON
app.get('/get/messages/:mittente', (req, res) => {
    const mittente = req.params.mittente;
  
    const query = 'SELECT * FROM Messaggio WHERE mittente = ?';
  
    db.query(query, [mittente], (error, results) => {
      if (error) {
        console.error('Errore nella query:', error);
        res.status(500).json({ error: 'Errore nella query del database' });
        return;
      }
  
      const messaggi = results.map((row) => ({
        id: row.id,
        testo: row.testo,
        link: row.link,
        localita: row.localita,
        immagine: row.immagine,
        destinatario: row.destinatario,
        mittente: row.mittente,
        impressionX: row.impressionX,
        categoria: row.categoria,
        data: row.data.toISOString().replace(/T/, ' ').replace(/\..+/, ''),
      }));
  
      res.json(messaggi);
    });
  });


//GET /canaliSQEALER - Recupera tutti i canali gestiti dal moderatore
app.get('/get/canaliSquealer', (req, res) => {
  const sql = 'SELECT * FROM Canale WHERE tipo="Ufficiali"';
      db.query(sql, (err, result)=>{
        res.send(result);
    })
});

//GET - canaliSQEALER Specifico - Recupera tutti i canali gestiti dal moderatore
app.get('/get/canale/:canaleNome', (req, res) => {
  const sql = `SELECT * FROM Canale WHERE tipo="Ufficiali" AND nome="${req.params.canaleNome}"`;
  db.query(sql, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Errore del server');
    } else {
      res.send(result);
    }
  });
});


//DELETE - rimuove il canale letteraMax selezionato
app.delete('/delete/canale/:canaleNome', (req, res) => {
  const canaleNome = req.params.canaleNome;
  const sql = `DELETE FROM Canale WHERE tipo="Ufficiali" AND nome="${canaleNome}"`;
  
  db.query(sql, (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Errore del server');
    } else {
      res.status(200).send('Canale eliminato correttamente');
    }
  });
});


//POST - Per Aggiunta Utenti 
app.post('/post/utenti', (req, res) => {
  const email = req.body.username;
  const password = req.body.password;
  const nome = req.body.name;
  const cognome = req.body.surname;

  // Chiamata alla stored procedure
  db.query(
    'CALL InserisciUtente(?, ?, ?, ?)',
    [email, password, nome, cognome],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});


app.post('/changePassword', (req, res) => {
  const email = req.body.username;
  const { newPassword } = req.body;

  // Chiamata alla stored procedure MySQL
  db.query('CALL CambioPassword(?, ?)', [email, newPassword], (error, results) => {
    if (error) {
      // In caso di errore durante l'esecuzione della stored procedure
      console.error(error);
      res.status(500).json({ error: 'Internal server error.' });
    } else {
      const message = results && results.affectedRows > 0 ? 'Password updated successfully.' : 'Invalid email or new password.';
      const statusCode = results && results.affectedRows > 0 ? 200 : 401;
      res.status(statusCode).json({ message });
    }
  });
});

//POST Per Aggiunta Messaggi 
app.post('/post/Messaggi', (req, res) => {
  const testo = req.body.testo || null; // Valore predefinito vuoto se 'testo' è mancante
  const latititude = req.body.latititude || 0; // Valore predefinito 0 se 'latititude' è mancante
  const longitude = req.body.longitude || 0; // Valore predefinito 0 se 'longitude' è mancante 
  const immagine = req.body.immagine || null; // Valore predefinito array vuoto se 'immagine' è mancante
  const destinatario = req.body.destinatario ||  null; // Valore predefinito array vuoto se 'destinatario' è mancante
  const mittente = req.body.mittente  || null; // Valore predefinito vuoto se 'mittente' è mancante
  const categoria = req.body.categoria || 'pubblico'; // Valore predefinito vuoto se 'categoria' è mancante
  const data = req.body.data ||null;
  const menzione = req.body.menzione ||null; // Valore predefinito data corrente se 'data' è mancante
  console.log(testo, latititude, longitude, immagine, destinatario, mittente, categoria, data,menzione);
  // Chiamata alla stored procedure
  db.query(
    'CALL InserisciPost(?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [testo, latititude, longitude, immagine, destinatario, mittente, categoria, data,menzione],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error });
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});



//POST -Per aggiunta Caratteri giornalieri

app.post('/post/AggiuntaCaratteri', (req, res) => {
  const mail = req.body.mail;
  const newChar = req.body.newChar;

  // Chiamata alla stored procedure
  db.query(
    
    'CALL AcquistoChar(?, ?)',
    [mail, newChar], (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});





//POST Per Aggiunta dei canali lettera Max

app.post('/post/CanaleMax', (req, res) => {
  const { nome } = req.body;

  // Chiamata alla stored procedure
  db.query(
    'CALL CreaCanaleUfficiale(?)',
    [nome], (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});




// Funzione per aggiornare lo stato dell'utente
function updateUserStatus(mail, nuovoStato) {
  const sql = `UPDATE Utente SET stato = ? WHERE email = ?`;
  db.query(sql, [nuovoStato, mail], (err, result) => {
      if (err) throw err;
      console.log('Stato dell\'utente aggiornato');
  });
}

// PUT - Cambio stato utente
app.put('/api/utenti/:mail/stato', (req, res) => {
  const mail = req.params.mail;
  const nuovoStato = req.body.stato;

  updateUserStatus(mail, nuovoStato);

  const utenteAggiornato = {
      mail,
      stato: nuovoStato
  };
  res.json(utenteAggiornato);
});


//GET - RICERCA CANALI LETTERA MAX
app.get('/search/canaliSquealer', (req, res) => {
  const query = req.query.query;
  const sql = 'SELECT * FROM Canale WHERE nome LIKE ? AND tipo="Ufficiali"';
  const params = [`%${query}%`];

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Errore durante la query:', err);
      res.status(500).json({ error: 'Errore durante la ricerca dei canali' });
      return;
    }
    res.json(results);
  });
});


// PUT - Cambio Descrizione dei Canali
app.put('/put/ModifyCanale/:channelName', (req, res) => {
  const channelName = req.params.channelName;
  const newDescription = req.body.description;

  const sql = 'UPDATE Canale SET descrizione = ? WHERE nome = ?';

  db.query(sql, [newDescription, channelName], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'An error occurred while updating the channel description.' });
    } else {
      res.status(200).json({ success: 'Channel description updated successfully.' });
    }
  });
});

/**NUOVE API DA AGGIUNGERE**/

app.get('/get/like/:mittente', (req, res) => {
  const mittente = req.params.mittente;
  const sql = 'CALL ContaGiudiziPositiviPerMittente(?)';

  db.query(sql, [mittente], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send("Errore durante la query al database");
    } else {
      res.json(result[0][0]); 
    }
  });
});


app.get('/get/dislike/:mittente', (req, res) => {
  const mittente = req.params.mittente;
  const sql = 'CALL ContaGiudiziNegativiPerMittente(?)';

  db.query(sql, [mittente], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send("Errore durante la query al database");
    } else {
      res.json(result[0][0]); 
    }
  });
});

/*1) GET MESSAGGI UTENTE*/

app.get('/get/messaggiUtente/:utenteMail', (req, res) => {
  const utenteMail = req.params.utenteMail;
  const sql = 'SELECT Messaggio.*, Utente.* FROM Messaggio JOIN Utente ON Messaggio.mittente = Utente.email WHERE ((?) IS NULL OR (?) = Messaggio.destinatario) OR ((?) IS NULL OR (?) = Messaggio.mittente) OR Messaggio.categoria = "pubblico" OR Messaggio.destinatario IN (SELECT FollowerCanale.nomeCanale FROM FollowerCanale WHERE (?) = FollowerCanale.iscritto) ORDER BY Messaggio.id DESC;';

db.query(sql, [utenteMail, utenteMail,utenteMail,utenteMail,utenteMail], (err, result) => {
    if (err) {
        console.error('Errore nella query:', err);
        return res.status(500).send('Errore nella query.');
    }
    res.send(result);
});
});

/*2) GET CANALI UTENTE ISCRITTO*/

app.get('/get/canaliIscrittoUtente/:utenteMail', (req, res) => {
  const utenteMail = req.params.utenteMail;
  const sql = `
    SELECT *
    FROM Canale
    WHERE (Canale.nome IN (
      SELECT FollowerCanale.nomeCanale
      FROM FollowerCanale
      WHERE (FollowerCanale.iscritto = ?)
    ))
    OR (Messaggio.mittente = ? AND Messaggio.categoria = "pubblico")
    OR (Messaggio.destinatario IN (
      SELECT FollowerCanale.nomeCanale
      FROM FollowerCanale
      WHERE (? = FollowerCanale.iscritto)
    ))
    `;
  
  db.query(sql, [utenteMail, utenteMail, utenteMail], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});




/*3) GET CANALI UTENTE NON ISCRITTO*/

app.get('/get/canaliNonIscrittoUtente/:utenteMail', (req, res) => {
  const utenteMail = req.params.utenteMail;
  const sql = `
    SELECT *
    FROM Canale
    WHERE (Canale.nome NOT IN (
      SELECT FollowerCanale.nomeCanale
      FROM FollowerCanale
      WHERE (FollowerCanale.iscritto = ?)
    ))
    OR (Messaggio.mittente = ? AND Messaggio.categoria = "pubblico")
    OR (Messaggio.destinatario IN (
      SELECT FollowerCanale.nomeCanale
      FROM FollowerCanale
      WHERE (? = FollowerCanale.iscritto)
    ))
  `;

  db.query(sql, [utenteMail, utenteMail, utenteMail], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});



/*4) GET CANALI PROPRIETA'*/
app.get('/get/canaliProprieta/:utenteMail', (req, res) => {
  const utenteMail = req.params.utenteMail;
  const sql = 'SELECT * FROM Canale WHERE (? = Canale.EmailProprietario)';

  db.query(sql, [utenteMail], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});



/*5) GET REAZIONI N POSITVE MESSAGGIO'*/
app.get('/get/reazioniPos/:idMessaggio', (req, res) => {
  const idMessaggio = req.params.idMessaggio;
  const sql = 'SELECT count(*) as count FROM Reazioni WHERE (Reazioni.idMessaggio = ?) AND (Reazioni.reazione = "positivo")';

  db.query(sql, [idMessaggio], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});





/*5) GET REAZIONI N POSITVE MESSAGGIO'*/
app.get('/get/reazioniNeg/:idMessaggio', (req, res) => {
  const idMessaggio = req.params.idMessaggio;
  const sql = 'SELECT count(*) as count FROM Reazioni WHERE (Reazioni.idMessaggio = ?) AND (Reazioni.reazione = "negativo")';

  db.query(sql, [idMessaggio], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});


/*POST*/
/*1) AGGIUNTA ISCRITTO */
//POST Per Aggiunta Messaggi 
app.post('/post/Iscritto', (req, res) => {

  const nuovoIscritto = req.body.iscritto;
  const canaleAssociato = req.body.canaleAssociato;

  // Chiamata alla stored procedure
  db.query(
    'CALL FollowDiretto(?, ?)',
    [nuovoIscritto, canaleAssociato],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      res.send(results); }
  );
});
/*2) AGGIUNTA REAZIONE POSITIVA */
//POST Per Aggiunta Messaggi 
app.post('/post/ReazionePositiva', (req, res) => {

  const idMessaggio = req.body.idMessaggio;
  const email = req.body.email;

  // Chiamata alla stored procedure
  db.query(
    'CALL AggiuntaLike(?,?)',
    [idMessaggio, email],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }
      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});


/*3) AGGIUNTA REAZIONE NEGATIVA */
//POST Per Aggiunta Messaggi 
app.post('/post/ReazioneNegativa', (req, res) => {

  const idMessaggio = req.body.idMessaggio;
  const email = req.body.email;

  // Chiamata alla stored procedure
  db.query(
    'CALL AggiuntaDislike(?,?)',
    [idMessaggio, email],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }
 // Elabora i risultati se necessario
 console.log('Risultati:', results);
 return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
     }
  );
});
/*4) AGGIUNTA AMMINISTRATORE CANALE */
//POST Per Aggiunta Messaggi 
app.post('/post/AddAdmin', (req, res) => {

  const nomeCanale = req.body.nomeCanale;
  const utenteAssociato = req.body.utenteAssociato;

  // Chiamata alla stored procedure
  db.query(
    'CALL AggiungiAdmin(?, ?)',
    [nomeCanale, utenteAssociato],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      res.send(results);}
  );
});

/*5) AGGIUNTA MENZIONE */

//POST Per Aggiunta Menzione 
app.post('/post/AggiungiMenzione', (req, res) => {

  const idMessaggio = req.body.idMessaggio;
  const menzionato = req.body.menzionato;

  // Chiamata alla stored procedure
  db.query(
    'CALL AggiungiTag(?, ?)',
    [idMessaggio, menzionato],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      res.send(results); }
  );
});


// ############################################################

//GET - Restituzione CANALI LETTERA MIN
app.get('/get/canaliMinSquealer', (req, res) => {
  const sql = 'SELECT * FROM Canale WHERE tipo="Personali"';
  db.query(sql, (err, result)=>{
    res.send(result);
})
});


// PUT - Cambio Descrizione dei Canali
app.put('/put/ModifyCanale/:channelName', (req, res) => {
  const channelName = req.params.channelName;
  const newDescription = req.body.description;

  const sql = 'UPDATE Canale SET descrizione = ? WHERE nome = ?';

  db.query(sql, [newDescription, channelName], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'An error occurred while updating the channel description.' });
    } else {
      res.status(200).json({ success: 'Channel description updated successfully.' });
    }
  });
});


//PUT - PER MODIFICARE PROPRIETARIO E DESCRIZIONE DEI CANALI LETTERAMIN 

// Modifica il proprietario di un canale letteraMin
app.put('/proprietario/:nome', (req, res) => {
  const { nome } = req.params;
  const { nuovoProprietario } = req.body;

  const query = 'UPDATE Canale SET EmailProprietario = ? WHERE nome = ? AND tipo = "Personali"';
  db.query(query, [nuovoProprietario, nome], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica del proprietario:', err);
      res.status(500).json({ error: 'Errore durante la modifica del proprietario' });
    } else {
      res.json({ message: 'Proprietario modificato con successo' });
    }
  });
});


// Modifica il nome di un canale letteraMin
app.put('/canali/:nome/nome', (req, res) => {
  const { nome } = req.params;
  const { nuovoNome } = req.body;

  const query = 'UPDATE Canale SET nome = ? WHERE nome = ? AND tipo = "Personali"';
  db.query(query, [nuovoNome, nome], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica del nome:', err);
      res.status(500).json({ error: 'Errore durante la modifica del nome' });
    } else {
      res.json({ message: 'Nome modificato con successo' });
    }
  });
});



// Modifica stato di un canale letteraMin
app.put('/canali/:nome/stato', (req, res) => {
  const nome = req.params.nome;
  const { stato } = req.body; 
  console.log("nome:   " + nome);

  const query = 'UPDATE Canale SET stato = ? WHERE nome = ? AND tipo = "Personali"';
  db.query(query, [stato, nome], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica del nome:', err);
      res.status(500).json({ error: 'Errore durante la modifica del nome' });
    } else {
      console.log(results);
      res.json({ message: results });
    }
  });
});


// Modifica il proprietario di un canale letteraMin
app.put('/canali/:nome/proprietario', (req, res) => {
  const { nome } = req.params;
  const { nuovoProprietario } = req.body;

  const query = 'UPDATE Canale SET EmailProprietario = ? WHERE nome = ? AND tipo = "Personali"';
  db.query(query, [nuovoProprietario, nome], (err, results) => {
    if (err) {
      console.error('Errore durante la modifica del proprietario:', err);
      res.status(500).json({ error: 'Errore durante la modifica del proprietario' });
    } else {
      res.json({ message: 'Proprietario modificato con successo' });
    }
  });
});


//GET /squealer- Recupera tutti i squealer
app.get('/get/squealer', (req, res) => {
  const sql = 'SELECT * FROM Messaggio';
      db.query(sql, (err, result)=>{
        res.send(result);
    })
});

// PUT - Cambio Descrizione dei Canali
app.put('/updateChannelDescription/:channelName', (req, res) => {
  const channelName = req.params.channelName;
  const newDescription = req.body.description;

  const sql = 'UPDATE Canale SET descrizione = ? WHERE nome = ?';

  db.query(sql, [newDescription, channelName], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'An error occurred while updating the channel description.' });
    } else {
      res.status(200).json({ success: 'Channel description updated successfully.' });
    }
  });
});


// Modifica il destinatario di un messaggio
app.put('/api/modifica-destinatario/:messaggioId', (req, res) => {
  const messaggioId = req.params.messaggioId;
  const nuovoDestinatario = req.body.nuovoDestinatario;
  
  // Query SQL per la modifica del destinatario
  const query = `UPDATE Messaggio SET destinatario = ? WHERE id = ?`;
  
  db.query(query, [nuovoDestinatario, messaggioId], (err, result) => {
    if (err) {
      console.error('Errore nella modifica del destinatario:', err);
      res.status(500).json({ success: false, error: 'Errore nella modifica del destinatario' });
      return;
    }
    res.json({ success: true, message: 'Destinatario modificato con successo' });
  });  
});


//GET -RESTITUISCE COMMENTI IN BASE A DESTINATARIO
app.get('/api/commenti/:emailDestinatario', (req, res) => {
  const emailDestinatario = req.params.emailDestinatario;
  const sql = `
    SELECT * 
    FROM Commento 
    WHERE EmailCreatore = ?;
  `;

  db.query(sql, [emailDestinatario], (err, result) => {
    if (err) {
      console.error('Errore nella query: ' + err);
      res.status(500).json({ error: 'Errore nel server.' });
    } else {
      res.status(200).json(result);
    }
  });
});


//GET apprezzamento
app.get('/get/apprezzamento', (req, res) => {
  const sql = 'SELECT * FROM Reazioni';
      db.query(sql, (err, result)=>{
        res.send(result);
    })
});


app.put('/api/modifica-giudizio/:idMessaggio', (req, res) => {
  const idMessaggio = req.params.idMessaggio;
  const { giudizio } = req.body; 

  db.query(
    'UPDATE Reazioni SET reazione = ? WHERE idMessaggio = ?',
    [giudizio, idMessaggio],
    (error, results) => {
      if (error) {
        console.error('Errore durante l\'aggiornamento del giudizio:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' });
      }

      if (results.affectedRows === 0) {
        // Nessun messaggio con quell'ID è stato trovato
        return res.status(404).json({ error: 'Messaggio non trovato' });
      }

      return res.status(200).json({ message: 'Giudizio aggiornato con successo' });
    }
  );
});


//GET /squealer- Recupera tutti gli squeal pubblici  
app.get('/get/squealPubblici', (req, res) => {  
  const sql = 'SELECT * FROM Messaggio WHERE categoria = "pubblico"';  
      db.query(sql, (err, result)=>{  
        res.send(result);  
    })  
});  

// POST - Per Aggiunta RICHIESTA DI ACQUISTO CANALE 
app.post('/post/richiestaAcquisto/:acquirente', (req, res) => {   
 
  const acquirente = req.params.acquirente; 
  const canale = req.body.canale; 
 
  db.query( 
    'CALL InserisciRichiesta(?, ?)', 
    [acquirente, canale], 
    (error, results) => { 
      if (error) { 
        console.error('Errore durante l\'esecuzione della stored procedure:', error); 
        console.error('Error stack:', error.stack); 
        return res.status(500).json({ error: 'Errore interno del server' + error }); 
      } 
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results }); 
    } 
  ); 
 
}); 

// PUT - Cambio esito richiesta acquisto del canale 
app.put('/put/modificaEsito/:idRichiestaAcquisto', (req, res) => { 
  const idRichiestaAcquisto = req.params.idRichiestaAcquisto; 
  const newEsito = req.body.newEsito; 
 
  const sql = 'UPDATE Richieste SET esito = ? WHERE id = ?'; 
 
  db.query(sql, [newEsito, idRichiestaAcquisto], (err, result) => { 
    if (err) { 
      console.error(err); 
      res.status(500).json({ error: 'An error occurred while updating the channel description.' }); 
    } else { 
      res.status(200).json({ success: 'Channel description updated successfully.' }); 
    } 
  }); 
}); 
 
// PUT - Cambio proprietario del canale 
app.put('/put/modificaProprietario/:canale', (req, res) => { 
 
  const canale = req.params.canale; 
  const newProprietario = req.body.newProprietario; 
 
  const sql = 'UPDATE canale SET EmailProprietario = ? WHERE nome = ?'; 
 
  db.query(sql, [newProprietario, canale], (err, result) => { 
    if (err) { 
      console.error(err); 
      res.status(500).json({ error: 'An error occurred while updating the channel property.' }); 
    } else { 
      res.status(200).json({ success: 'Channel description updated successfully.' }); 
    } 
  }); 
}); 
 
//GET - Recupera tutte le richieste di acquisto in attesa 
app.get('/get/richiesteAcquisto/:venditore', (req, res) => { 
  const venditore = req.params.venditore; 
  const sql = 'SELECT id, canale, acquirente, esito FROM Richieste WHERE (venditore = ?) AND esito = "in attesa"'; 
      db.query(sql, [venditore], (err, result)=>{ 
        if (err) { 
          console.error('Errore nella query:', err); 
          return res.status(500).send('Errore nella query.'); 
        } 
        res.send(result); 
    }) 
}); 
 
//GET - Recupera tutte le richieste di acquisto accettate 
app.get('/get/richiesteAccettate/:venditore', (req, res) => { 
  const venditore = req.params.venditore; 
  const sql = 'SELECT id, canale, acquirente, esito FROM Richieste WHERE (venditore = ?) AND esito = "accettata"'; 
      db.query(sql, [venditore], (err, result)=>{ 
        if (err) { 
          console.error('Errore nella query:', err); 
          return res.status(500).send('Errore nella query.'); 
        } 
        res.send(result); 
    }) 
}); 
 
//GET - Recupera tutte le richieste di acquisto in attesa 
app.get('/get/richiesteRifiutate/:venditore', (req, res) => { 
  const venditore = req.params.venditore; 
  const sql = 'SELECT id, canale, acquirente, esito FROM Richieste WHERE (venditore = ?) AND esito = "rifiutata"'; 
      db.query(sql, [venditore], (err, result)=>{ 
        if (err) { 
          console.error('Errore nella query:', err); 
          return res.status(500).send('Errore nella query.'); 
        } 
        res.send(result); 
    }) 
}); 
 
// POST - Per Aggiunta RICHIESTA DI ACQUISTO CANALE 
app.post('/post/nuovoCanale/:creatore', (req, res) => {   
 
  const creatore = req.params.creatore; 
  const nomeCanale = req.body.nomeCanale; 
  const descrizioneCanale = req.body.descrizioneCanale; 
 
  db.query( 
    'INSERT INTO Canale (nome, descrizione, tipo, EmailProprietario) VALUES (?, ?, "Personali", ?);', 
    [nomeCanale, descrizioneCanale, creatore], 
    (error, results) => { 
      if (error) { 
        console.error('Errore durante l\'esecuzione della stored procedure:', error); 
        console.error('Error stack:', error.stack); 
        return res.status(500).json({ error: 'Errore interno del server' + error }); 
      } 
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results }); 
    } 
  ); 
 
});


 

//DELETE - rimuove il utente
app.delete('/delete/utente/:email', (req, res) => {
  const email = req.params.email;
  const sql = `DELETE FROM Utente WHERE  (email= ?)`;
  
  db.query(sql,[email], (err, result) => {
    if (err) {
      console.error(err);
      res.status(500).send('Errore del server');
    } else {
      res.status(200).send('Account eliminato correttamente');
    }
  });
});


//GET - RICERCA CANALI LETTERA MAX
app.get('/search/canaliSquealer', (req, res) => {
  const query = req.query.query;
  const sql = 'SELECT * FROM Canale WHERE nome LIKE ?';
  const params = [`%${query}%`];

  db.query(sql, params, (err, results) => {
    if (err) {
      console.error('Errore durante la query:', err);
      res.status(500).json({ error: 'Errore durante la ricerca dei canali' });
      return;
    }
    res.json(results);
  });
});

// POST - Per Aggiunta Iscritto ad un canale
app.post('/post/iscritto', (req, res) => {  
  console.log("Sono passato");
  const canale = req.body.canale; // Cambio da 'username' a 'canale'
  const utente = req.body.utente; // Cambio da 'password' a 'utente'

  console.log(canale,utente);
  // Chiamata alla stored procedure
  db.query(
    'INSERT INTO FollowerCanale (nomeCanale, iscritto) VALUES (?, ?)', // Correzione della query
    [canale, utente],
    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error });
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});


app.get('/get/destinatari', (req, res) => {
  const sql = 'SELECT email FROM Utente UNION SELECT nome as email from Canale where stato="sbloccato" AND tipo="Personali" ';
      db.query(sql, (err, result)=>{
        res.send(result);
    })
});

app.get('/get/utentimenzionati', (req, res) => {
  const sql = 'SELECT email FROM Utente ';
      db.query(sql, (err, result)=>{
        res.send(result);
    })
});

app.get('/get/canalimenzionati', (req, res) => {
  const sql = ' SELECT nome as email from Canale where stato="sbloccato"';
      db.query(sql, (err, result)=>{
        res.send(result);
    })
});


//POST - PER L'AGGIUNTA COMMENTI
app.post('/aggiungiCommento', (req, res) => {
  const { idMessaggio, emailMittente, emailDestinatario, testo } = req.body;

  const query = `CALL AggiuntaCommento(?, ?, ?, ?);`;

  db.query(query, [idMessaggio, emailMittente, emailDestinatario, testo], (error, results) => {
    if (error) {
      console.error('Errore durante esecuzione della stored procedure:', error);
      res.status(500).json({ message: 'Errore durante esecuzione della stored procedure' });
    } else {
      const message = results.Messaggio;
      res.json({ message });
    }
  });
});


app.get('/get/commenti/:idMessaggio', (req, res) => {
  const idMessaggio = req.params.idMessaggio;
  
  const query = 'SELECT * FROM Commento WHERE idMessaggio = ?';
  
  db.query(query, [idMessaggio], (err, rows) => {
    if (err) {
      console.error('Errore durante la query del database:', err);
      res.status(500).json({ error: 'Errore del server' });
    } else {
      res.json(rows);
    }
  });
});



/*3) GET CANALI UTENTE NON ISCRITTO*/

app.get('/canaliNonIscrittoUtente/:utenteMail', (req, res) => {
  const utenteMail = req.params.utenteMail;
  const sql = `
    SELECT *
    FROM Canale
    WHERE (Canale.nome NOT IN (
      SELECT FollowerCanale.nomeCanale
      FROM FollowerCanale
      WHERE (FollowerCanale.iscritto = ?)
    ))
  `;

  db.query(sql, [utenteMail], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});


/*3) GET CANALI UTENTE ISCRITTO*/

app.get('/canaliIscrittoUtente/:utenteMail', (req, res) => {
  const utenteMail = req.params.utenteMail;
  const sql = `
    SELECT *
    FROM Canale
    WHERE (Canale.nome IN (
      SELECT FollowerCanale.nomeCanale
      FROM FollowerCanale
      WHERE (FollowerCanale.iscritto = ?)
    ))
  `;

  db.query(sql, [utenteMail], (err, result) => {
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  });
});



//POST - Per Aggiunta Utenti 
app.post('/post/canaliIscritti/:emailUtente', (req, res) => {
  const nomeCanale = req.body.nomeCanale;
  const emailUtente = req.params.emailUtente;
  
  db.query(
    'INSERT INTO FollowerCanale(nomeCanale, iscritto) VALUES (?, ?) ',
    [nomeCanale, emailUtente],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );
});


// DELETE - Per Rimuovere Utenti da un Canale
app.delete('/delete/canaliIscritti/:emailUtente', (req, res) => {
  const nomeCanale = req.body.nomeCanale;
  const emailUtente = req.params.emailUtente;
  
  db.query(
    'DELETE FROM FollowerCanale WHERE nomeCanale = ? AND iscritto = ?',
    [nomeCanale, emailUtente],

    (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error });
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Eliminazione eseguita correttamente', results });
    }
  );
});



// Configura il middleware multer per gestire il caricamento dei file

const storage = multer.diskStorage({

  destination: function (req, file, cb) {

    cb(null, '../../public/saved'); // la directory in cui salvare i file caricati

  },

  filename: function (req, file, cb) {

    cb(null, file.originalname); // nome del file originale

  },

});


app.use(express.static('public'));
app.use('/saved', express.static('saved'));
 

const upload = multer({ storage: storage });

 

// Route per gestire il caricamento dell'immagine

app.post('/upload', upload.single('image'), (req, res) => {
  res.sendStatus(200).json({ message: 'File uploaded successfully' }); // Invia una risposta di successo

});


//DELETE - rimuove il MESSAGGIO 
app.delete('/remove/messages/:id', (req, res) => {
  const messageId = req.params.id;

  const deleteQuery = 'DELETE FROM Messaggio WHERE id = ?';

  db.query(deleteQuery, [messageId], (err, results) => {
    if (err) {
      console.error('Error deleting message:', err);
      res.status(500).json({ error: 'An error occurred while deleting the message.' });
    } else if (results.affectedRows === 0) {
      res.status(404).json({ error: 'Message not found.' });
    } else {
      res.status(200).json({ message: 'Message deleted successfully.' });
    }
  });
});



//GET - restituzione messaggi dei CANALI LETTERA MAX 
app.get('/get/messaggiCanaliMax', (req, res) => { 
 
  const sql = 'SELECT * FROM messaggio, canale WHERE destinatario = canale.nome AND canale.tipo="Ufficiali"'; 
 
  db.query(sql, (err, results) => { 
    if (err) { 
      console.error('Errore durante la query:', err); 
      res.status(500).json({ error: 'Errore durante la ricerca dei canali' }); 
      return; 
    } 
    res.json(results); 
  }); 
});


app.post('/post/RemoveChar', (req, res) => {
  const mail = req.body.mail;
  const newChar = req.body.newChar;
  db.query(
    
    'CALL Consumo(?, ?)',
    [mail, newChar], (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );

});


app.post('/post/AggiuntaChar', (req, res) => {
  const mail = req.body.mail;
  const newChar = req.body.newChar;
  db.query(
    
    'CALL Aggiunta(?, ?)',
    [mail, newChar], (error, results) => {
      if (error) {
        console.error('Errore durante l\'esecuzione della stored procedure:', error);
        console.error('Error stack:', error.stack);
        return res.status(500).json({ error: 'Errore interno del server' + error});
      }

      // Elabora i risultati se necessario
      console.log('Risultati:', results);
      return res.status(200).json({ message: 'Stored procedure eseguita correttamente', results });
    }
  );

});




//GET /messages - Recupera tutti i messaggi di un canale

app.get('/get/messaggiDelCanale/:canale', (req, res) => {

 

  const canale = req.params.canale;

 

  const query = 'SELECT * FROM Messaggio WHERE destinatario = ?';


  db.query(query, [canale], (err, result)=>{
    if (err) {
      console.error('Errore nella query:', err);
      return res.status(500).send('Errore nella query.');
    }
    res.send(result);
  })
});


app.listen(3001, () =>{
    console.log("running on port 3001;")
});
